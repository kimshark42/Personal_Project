import './Process.css'

import { useState } from "react";

import PAGE from "./PAGE.js";
import Main from "../main/Main.js";
import RpgMain from '../samechynrpg/RpgMain.js';
import SandwichMain from "../sandwichtetra/SandwichMain.js";
import TestTeteres from "../sandwichtetra/TestTeteres.js"
import Samechan_rpg_game from '../samechynrpg/SamechynRpg.js';

function SharkController() {
    // 여러 페이지 상태를 배열로 분리
    var [currentPage, setCurrentPage] = useState(PAGE.MAIN_PAGE);

    // 페이지를 바꾸기 위한 도우미 함수
    function changePageMode(page){setCurrentPage(page);}

    return (
        <div>
            {/* 기본 페이지를 Main.js로 기본 출력하게끔 세팅 */}
            {currentPage === PAGE.MAIN_PAGE && <Main changePageMode={changePageMode} />}
            {currentPage === PAGE.SAMECHAN_RPG && <RpgMain changePageMode={changePageMode} />}
            {currentPage === PAGE.SANDWICH_TETRA && <SandwichMain changePageMode={changePageMode} />}

            {/* 샌드위치 테트라 관련 */}
            {currentPage === PAGE.TEST_TETERES && <TestTeteres changePageMode={changePageMode} />}

            {/* 사메챤 RPG 관련 */}
            {currentPage === PAGE.SAMECHAN_RPG_GAME && <Samechan_rpg_game changePageMode={changePageMode} />}
        </div>
    );
}

export default SharkController;