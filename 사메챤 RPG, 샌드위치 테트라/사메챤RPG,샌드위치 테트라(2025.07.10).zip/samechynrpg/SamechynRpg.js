import './SamechynRpg.css';

import PAGE from "../process/PAGE";
import RpgComponent from "./rpgcomponent/RpgComponent";

function Samechan_rpg_game({changePageMode}) {
    return (
        <RpgComponent>
            {{
                sidebar: (
                    <div>
                        {/* 사이드바 내부 */}
                        <div className="character"></div>
                        <div className="game_clock">11:11</div>
                        <button onClick={()=>changePageMode(PAGE.SAMECHAN_RPG)}>이전으로</button>
                    </div>
                ), main: (
                    <div>
                        {/* 메인 컨텐츠 영역 */}
                        <div className="game_panel">
                            <textarea className="screen_game_object" readOnly></textarea>
                            <textarea className="screen_message_box" readOnly></textarea>
                            <textarea className="screen_player_info" readOnly></textarea>
                            <hr />
                            <input className="input_txt_turn" value="0" readOnly />
                            <input type="button" value="턴 진행" />
                        </div>
                    </div>
                )
            }}
        </RpgComponent>
    );
}

export default Samechan_rpg_game;