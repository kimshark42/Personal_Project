/**********************************************************************************************************************
2025.07.07 일단 메인 화면에서 링크 클릭시 사메챤 RPG와 길드 샌드위치 테트라를 분리 접속 가능하게끔하기 <- 성공
2025.07.09 App.js 에서 있던 컨트롤러들 컨트롤러 전옹 js를 만들어서 관리하기 + TestTeteres로 버튼 클릭시 이동 <- 성공

todo
todo - css 대신 js내에서의 style을 사용할것인지 생각해보기

사메챤 RPG
todo - 인게임 화면 텍스트 상자 구성
todo - 메인화면 className이 공용 이름으로 겹치기 때문에 RPG 전용으로 이름 변경하기

샌드위치 테트라
todo - 벽을 넘어갔을때, 유효범위와 무효범위 지정 + 무효범위 or 무효 동작이 작동했을 시 return하게끔 하기
************************************************************************************************************************/

// 메인화면
import './Main.css';

import PAGE from "../process/PAGE";

function Main({changePageMode}) {
    return (
        <div className="main">
            <div className="main_button">
                <button onClick={()=> changePageMode(PAGE.SAMECHAN_RPG)}>사메챤RPG</button>
                <button onClick={()=> changePageMode(PAGE.SANDWICH_TETRA)}>샌드위치 테트라</button>
            </div>
        </div>
    );
}

export default Main;