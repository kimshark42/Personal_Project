import './RpgMain.css';

import { useState } from "react";

import PAGE from "../process/PAGE";

function Rpgmain({changePageMode}) {

    // 사이드바 펼치고 접기
    const [isOpen, setlsOpen] = useState(true);

    return (
        <div className="rpg_main">
            {/* 사이드바 버튼 */}
            {/* 2025.07.09 추가 사이드바의 상태에 따라 버튼의 방향 변경 */}
            <button className="toggle-button" onClick={()=> setlsOpen(!isOpen)}>{isOpen ? '◀' : '▶'}</button>
            <aside className={`sidebar ${!isOpen ? "closed" : ""}`}>
                {/* 사이드바 내부 */}
                <div className="scroll-content">
                    <div className="logo"></div>
                    <div className="game_clock">00:00</div>
                    <p>사이드바 내용</p>
                    <button onClick={()=>changePageMode(PAGE.MAIN_PAGE)}>메인페이지로 돌아가기</button>
                </div>
            </aside>

            {/* 메인 컨텐츠 영역 */}
            <main className="main-content">
                <div className="big_logo"></div>
                <h1>사메챤 RPG</h1>

                {/* jsx 방식 */}
                <div className="button_test">
                    <button>따이 1</button>
                    <button>따이 2</button>
                    <button>따이 3</button>
                    <button>따이 4</button>
                    <button>따이 5</button>
                    <button>따이 6</button>
                </div>
            </main>
        </div>
    );
}

export default Rpgmain;