import { LINE } from "./TETRAS";
import useTetraState from "./useTetraState";

function GameOver() {
    const {
        grid, setGrid,
        isGameOver, setIsGameOver
    } = useTetraState();

    const handleRestart = (() => {
        const emptyGrid = Array.from({ length: LINE.ROWS }, () => Array(LINE.COLS).fill(0));
        setGrid(emptyGrid);
        setIsGameOver(false);
    })
    return (
        <button onClick={handleRestart}>재시작</button>
    );
}

export default GameOver;