import { LINE } from "./TETRAS";

// 줄 삭제 로직
function clearFullLines(grid) {
    const newGrid = grid.filter(row => row.some(cell => cell === 0));  // 꽉 찬 줄 제외
    const linesCleared = LINE.ROWS - newGrid.length;  // 줄이 몇개 제거되었는지

    // 위에서 줄 추가
    const emptyRows = Array.from({ length: linesCleared }, () => Array(LINE.COLS).fill(0));
    return [...emptyRows,...newGrid];
};

export default clearFullLines;