import { LINE } from "./TETRAS";

// 빈 필드 생성
const createEmptyField = () => Array.from({ length: LINE.ROWS }, () => Array(LINE.COLS).fill(0));

export default createEmptyField;