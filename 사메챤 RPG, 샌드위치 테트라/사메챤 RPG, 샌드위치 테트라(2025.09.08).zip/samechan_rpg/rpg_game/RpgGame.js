import { PAGE } from "../../process/PAGE";

function RpgGame({ changePageMode }) {
    return (
        <div>
            RpgGame
            <button onClick={() => changePageMode(PAGE.SAMECHAN_RPG)}>이전으로</button>
        </div>
    );
}

export default RpgGame;