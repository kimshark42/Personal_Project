import './ErrorPage.css';

import { PAGE } from "./PAGE";

function ErrprPage({ changePageMode }) {
    return (
        <div className='error_layout'>
            <div className='error_line'></div>
                <div className='error_content'>
                    <div className='error_message'>
                        <h1>잘못된 페이지 입니다.</h1>
                        <button onClick={() => changePageMode(PAGE.MAIN)}>메인 페이지로 돌아가기</button>
                        <h2>문열어!!!!</h2>
                    </div>
                    <div className="error_img">에러 이미지</div>
                </div>
            <div className='error_line'></div>
        </div>
    );
}

export default ErrprPage;