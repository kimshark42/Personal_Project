import './App.css';
import SharkController from './process/ShakController';

function App() {
  return (
    <div>
      <SharkController />
    </div>
  );
}

export default App;
