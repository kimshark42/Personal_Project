import './SandwichMain.css';

import { PAGE } from "../../process/PAGE";

function SandwichMain({ changePageMode }) {
    return (
        <div className='sandwich_main'>
            <div className='sandwich_main_content'>
                <div className='sandwich_main_big_logo'></div>
                <div className='sandwich_main_buttons'>
                    <button onClick={() => changePageMode(PAGE.SANDWICH_GAME)}>게임시작</button>
                    <button>게임 설정</button>
                    <button>도움말</button>
                    <button onClick={() => changePageMode(PAGE.MAIN)}>메인 페이지로</button>
                </div>
            </div>
        </div>
    );
}

export default SandwichMain;