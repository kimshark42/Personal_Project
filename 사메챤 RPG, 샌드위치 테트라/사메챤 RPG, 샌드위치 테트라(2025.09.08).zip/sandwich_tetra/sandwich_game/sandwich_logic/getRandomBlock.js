import { TETRAS } from "../TETRAS";

// 블럭을 무작위로 선별
function getRandomBlock() {
    console.log('getRandomBlock 작동함!!');  // 로그
    const keys = Object.keys(TETRAS);
    const randomkey = keys[Math.floor(Math.random()*keys.length)];
    return TETRAS[randomkey];
};

export default getRandomBlock;