import { PAGE } from "../process/PAGE";

import { useState } from "react";
import createEmptyField from "../sandwich_tetra/tetra_field/createEmptyField";
import Field from "../sandwich_tetra/tetra_field/Field";

function SandwichGame({ changePageMode }) {

    // 임시
    const [grid, setGrid] = useState(createEmptyField());

    return (
        <div>
            SandwichGame화면 진입
            <button onClick={() => changePageMode(PAGE.SANDWICH_TETRA)}>이전으로</button>
            <Field grid={grid} />
        </div>
    );
}

export default SandwichGame;