import './App.css';
import SharkController from './process/SharkController';

function App() {
  return (
    <div>
      <SharkController />
    </div>
  );
}

export default App;
