import { useState } from "react";
import { PAGE } from "./PAGE";
import SandwichMain from "../main/SandwichMain";
import SandwichGame from "../main/SandwichGame";

// 페이지 전환 코드
function SharkController() {

    // 여러 페이지 상태를 배열로 분리
    var [currentPage, setCurrentPage] = useState(PAGE.SANDWICH_TETRA);

    // 페이지를 바꾸기 위한 도우미 함수
    function changePageMode(page){setCurrentPage(page);}

    return (
        <div>
            {/* 기본 페이지를 SandwichMain.js로 출력하게끔 세팅 */}
            {currentPage === PAGE.SANDWICH_TETRA && <SandwichMain changePageMode={changePageMode} />}
            {currentPage === PAGE.TETRA_GAME && <SandwichGame changePageMode={changePageMode} />}
        </div>
    );
}

export default SharkController;