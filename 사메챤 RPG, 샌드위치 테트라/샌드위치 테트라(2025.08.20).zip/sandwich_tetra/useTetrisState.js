import { useState } from "react"
import createEmptyField from "./tetra_field/createEmptyField"
import { TETRAS } from "./TETRA";

const useTetrisState = () => {
    
    const [grid, setGrid] = useState(createEmptyField());
    const [currentBlock, setCurrentBlock] = useState({
        // 임시 지정
        shpe: TETRAS["T"].shape,
        pos: { x: 4, y: 0 },
        collided: false
    });

    const [nextBlock, setNextBlock] = useState();
}