import styled from 'styled-components'
import React from 'react'

import { TETRAS } from "../TETRA"

// 빈칸
const StyledEmptyCell = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    width: auto;
    
    border: 1px solid #111;
    background-color: black; `;

// 일반 블럭
const StyledCell1 = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    width: auto;
    
    border: 2px solid ${props => props.border};
    border-radius: 4px;
    background-color: ${props => props.color};
    
    div {
        width: 55%;
        height: 55%;

        border: 2px solid ${props => props.color};
        border-radius: 4px;
        background-color: ${props => props.border};
    }`

// 고스트 블럭
const StyledCell2 = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    width: auto;
    
    border: 1.5px solid rgba(0, 0, 0, 0.5);
    border: 1.5px solid black;
    border-radius: 4px; `

const Cell = ({ type, isGost }) => {
    
    const { color, border } = TETRAS[type] || TETRAS[0];

    // const color = TETRAS[type].color;
    // const border = TETRAS[type].border;

    if (type === '0') {
        return <StyledEmptyCell />
    }

    return isGost ?
        <StyledCell2 ghost={'true'} color={color} border={border}><div></div></StyledCell2> :
        <StyledCell1 type={type} color={color} border={border}>{type !== '0' && <div></div>}</StyledCell1>;
}

export default React.memo(Cell);  // 같은걸 재렌더링 방지(최적화)