import { LINE } from "../TETRA"

// 빈 필드 생성
const createEmptyField = () => {
    return Array.from({ length: LINE.ROWS }, () => Array.from({ length: LINE.COLS }, () => [0, 'clear']));
};

export default createEmptyField;