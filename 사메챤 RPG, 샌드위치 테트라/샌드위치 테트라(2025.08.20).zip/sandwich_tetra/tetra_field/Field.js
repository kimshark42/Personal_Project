import styled from "styled-components";
import Cell from "./Cell";

const StyledField = styled.div`
    display: grid;
    grid-template-rows: repeat(${props => props.rows}, 25px);
    grid-template-columns: repeat(${props => props.cols}, 25px);
    gap: 2px;
    background: pink;
    padding: 10px;
    border: 2px solid #fff;
    border-radius: 6px; `;

const Field = ({ grid }) => {
    return (
        <StyledField rows={grid.length} cols={grid[0].length}>
            {grid.map((row, y) => row.map((cell, x) => (<Cell key={`${y}-${x}`} type={String(cell[0])} isGhost={false} />)))}
        </StyledField>
    );
}

export default Field;