import './SandwichMain.css';

// 샌드위치 테트라 메인화면
function SandwichMain({ changePageMode }) {
    return (
        <div className="sandwich_main">
            <div className="sandwich_content">
                <div className="sandwich_big_logo"></div>
                <div className="sandwich_main_buttons">
                    <button>버튼 1</button>
                    <button>버튼 2</button>
                    <button>버튼 3</button>
                    <button>버튼 4</button>
                    <button>버튼 5</button>
                    <button>버튼 6</button>
                </div>
            </div>
        </div>
    );
}

export default SandwichMain;