// import { styled } from "styled-com"
// const TetraStyle = styled.div`
//     height: 100%;
//     display: flex;`