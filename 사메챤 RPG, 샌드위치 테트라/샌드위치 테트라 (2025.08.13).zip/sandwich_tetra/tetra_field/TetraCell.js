// import { TETRAS } from "../tetra/TETRAS"

// // const StyledCell1 = styled.div
// const TetraCell = ({ type }) => {
//     const color = TETRAS[type].color;
//     const border = TETRAS[type].border;

//     return (
//         <div></div>
//         // <StyledCell2 color={color} border={border}><div></div></StyledCell2>
//     );
// }