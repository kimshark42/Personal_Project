import { createSlice } from "@reduxjs/toolkit";

import createEmptyField from "../tetra_logic/createEmptyField";

// 초기 상태 정의
const initialState = {
    grid: createEmptyField(),  // 현재 게임 필드 (2차원 배열) - 각 칸의 블록 상태
    currentBlock: { shape: [], color: '', border: ''},  // 현재 떨어지고있는 블록의 모양과 색상
    blockPosition: { x: 0, y: 0 },  // 현재 블록의 좌표 위치
    isGameOver: false  // 게임 오버 여부
};

// Redux Slice 생성
// - name: slice 이름 (state 접근 시 state.isTetra)
// - initalState: 위에서 정의한 초기 상태
// - reducers: 상태를 변경하는 액션(함수) 모음
const IsTetra = createSlice({
    name: "isTetra",
    initialState,
    reducers: {
        // 게임 필드 전체를 새로 설정
        setGrid(state, action) {
            state.grid = action.payload;
        },

        // 현재 떨어지고 있는 블록 정보 변경
        setCurrentBlock(state, action) {
            state.currentBlock = action.payload;
        },

        // 현재 블록의 위치 변경
        setBlockPosition(state, action) {
            state.blockPosition = action.payload;
        },

        // 게임 오버 여부 설정
        setIsGameOver(state, action) {
            state.isGameOver = action.payload;
        },

        // 게임 전체를 초기화 (새 게임 시작 시)
        resetIsTetra(state) {
            // 초기 상태로 덮어쓰기
            state.grid = createEmptyField();
            state.currentBlock = { shape: [], color: '', border: ''};
            state.blockPosition = { x: 0, y: 0 };
            state.isGameOver = false;
        }
    }
});

// 액션 내보내기
// 컴포넌트에서 dispatch(setGrid(...)) 이런식으로 호출 가능
export const {
    setGrid,
    setCurrentBlock,
    setBlockPosition,
    setIsGameOver,
    resetIsTetra
} = IsTetra.actions;

export default IsTetra;