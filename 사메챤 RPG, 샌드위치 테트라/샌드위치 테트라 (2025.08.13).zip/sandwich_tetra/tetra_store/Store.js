// 샌드위치 테트라 Store

import { comfigureStore } from "@reduxjs/toolkit";

import IsTetra from "./IsTetra";

const store = comfigureStore({
    reducer: {
        isTetra: IsTetra.reducer,
    }
});

export default store;