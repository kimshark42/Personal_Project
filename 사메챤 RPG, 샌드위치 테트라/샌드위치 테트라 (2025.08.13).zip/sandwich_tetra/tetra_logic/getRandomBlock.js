import { TETRAS } from "../tetra/TETRAS";

// 랜덤으로 블록 드롭
function getRandomBlock() {
    console.log('getRandomBlock 작동함!!');  // 로그
    const keys = Object.keys(TETRAS).filter(k => k !== '0');  // 빈 블럭 제외하기
    const randomkey = keys[Math.floor(Math.random()*keys.length)];
    return TETRAS[randomkey];
}

export default getRandomBlock;