import { LINE } from "../tetra/TETRAS";

// 줄 삭제 로직
function clearFullLines(grid) {
    const newGrid = grid.filter(row => row.some(cell => cell[0] === 0));  // 꽉 찬 줄 제외
    const linesCleared = LINE.ROWS - newGrid.length;  // 제거된 줄의 갯수

    // 삭제된 줄 갯수 만큼 빈줄 추가
    const emptyRows = Array.from({ length: linesCleared }, () => Array(LINE.COLS).fill([ 0, "clear" ]));
    return [...emptyRows, ...newGrid];
}

export default clearFullLines;