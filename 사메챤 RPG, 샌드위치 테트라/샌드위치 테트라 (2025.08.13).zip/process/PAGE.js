// 페이지를 넘기는 상수 모음

const PAGE = {

    // 메인 화면 모음
    MAIN_PAGE : 'main_page',  // 메인 페이지
    SAMECHAN_RPG : 'samechan_rpg',  // 사메챤 RPG
    SANDWICH_TETRA : 'sandwich_tetra',  // 샌드위치 테트라
}

export default PAGE;