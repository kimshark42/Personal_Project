import { useState } from "react";

import PAGE from "./PAGE";
import Main from "../main/Main";
import SandwichMain from "../sandwich_tetra/SandwichMain";

// 페이지 변경 상태
function SharkController() {
    // 여러 페이지 상태를 배열로 분리
    var [currentPage, setCurrentPage] = useState(PAGE.MAIN_PAGE);  // 첫 페이지를 메인페이지로 설정

    // 페이지를 바꾸기위한 도우미 함수
    function changePageMode(page){setCurrentPage(page);}

    return (
        <div>
            {/* 기본 페이지를 Main.js로 기본 출력 */}
            {currentPage === PAGE.MAIN_PAGE && <Main changePageMode={changePageMode} />}
            {currentPage === PAGE.SANDWICH_TETRA && <SandwichMain changePageMode={changePageMode} />}

        </div>
    );
}

export default SharkController;