// Redux
import { Provider } from 'react-redux';

import SharkController from './process/SharkController';

function App() {
  return (
    <div>
      {/* <Provider store={store}> */}
        <SharkController />
      {/* </Provider> */}
    </div>
  );
}

export default App;
