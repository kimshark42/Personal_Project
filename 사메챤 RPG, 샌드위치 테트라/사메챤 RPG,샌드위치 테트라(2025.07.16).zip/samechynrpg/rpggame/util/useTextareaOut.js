import { useEffect, useState } from "react";
import Player from "./Player";
import Monster from "./Monster";

function useTextareaOut(advanceTurnCallback) {

    const [messageLog ,setMessageLog] = useState('');  // 메인 화면
    const [gameObjectLog, setGameObjectLog] = useState('');  // 적 몬스터 및 아이템 info
    const [playerInfo, setPlayerInfo] = useState('');  // 플레이어 info

    const [turnCount, setTurnCount] = useState(0);  // 턴 횟수 저장

    // class 인스턴스 생성
    const player = new Player("김상어", 70, 11);
    const slime = new Monster("슬라링", 12, 1)

    // 임시 테스트 구역
    const [playerHp, setPlayerHp] = useState(player.currenthp);
    const [slimeHp, setSlimeHp] = useState(slime.currenthp);

    // textarea에 text를 누적해서 찍어주는 함수
    const tx = (text) => {setMessageLog(prev => prev + text);};
    const txPlayerInfo = (text) => {setPlayerInfo(text);};
    const txGameObjectLog = (text) => {setGameObjectLog(text);};

    const handleTurn = () => {
        console.log('handleTurn 작동함');  // 로그
        advanceTurnCallback();

        // 공격처리
        const playerDamage = Math.floor(Math.random()*(player.attack + 1));
        const slimeDamage = Math.floor(Math.random()*(slime.attack + 1));

        slime.receiveDamageMonster(playerDamage);
        player.receiveDamagePlayer(slimeDamage);

        tx(`전투시작\n\n`);
        tx(`${slime.name}과 조우했다!! -${slime.attack}!!!\n\n`)
        txGameObjectLog(slime.info());
        tx(`[턴 ${turnCount + 1}]\n`);
        tx(`당신의 공격! ${playerDamage}의 데미지를 줬습니다.\n`)
        tx(`슬라링의 몸통박치기! ${slimeDamage}를 받았습니다.\n`)

        txGameObjectLog(`${slime.info()}`)
        txPlayerInfo(`${player.info()}`)

        setTurnCount(t => t+1);
        setPlayerHp(player.currenthp);
        setSlimeHp(slime.currenthp);
    }

    useEffect(() => {txPlayerInfo(`${player.info()}`);},[]);

    return {
        messageLog,
        gameObjectLog,
        playerInfo,
        turnCount,
        handleTurn,
    };
}

export default useTextareaOut;