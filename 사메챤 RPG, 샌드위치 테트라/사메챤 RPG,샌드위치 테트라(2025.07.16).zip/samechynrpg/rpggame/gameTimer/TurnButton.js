import './GameTimer.css';

function TurnButton({ display }) {
    return (
        <div className="game_clock">{display}</div>
    );
}

export default TurnButton;