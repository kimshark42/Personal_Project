import './TetraField.css';

function TetraField() {

    // 가로세로 격자
    const rows = 20;
    const cols = 10;

    return (
        <div className="tetra_field_test">
            <div className="tetra_grid"
                style={{
                    gridTemplateColumns: `repeat(${cols}, 1fr)`,
                    gridTemplateRows: `repeat(${rows}, 1fr)`
                }}>
                {Array.from({ length: rows*cols }).map(( _, c ) => (
                    <div key={c} className="tetra_cell" />
                ))}
            </div>
        </div>
    );
}

export default TetraField;