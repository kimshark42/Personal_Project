import './SandwichField.css';

import useSandwichState from '../useTetraState';
import { useEffect } from 'react';
import createEmptyField from '../sandwich_logic/createEmptyField';
import { LINE } from '../TETRAS';

// 필드 생성
function SandwichField() {

    // 각종 상태 공유
    const {
        grid, setGrid,
        currentBlock, setCurrentBlock,
        blockPosition, setBlockPosition,
    } = useSandwichState();

    // 바닥에 미리 깔아둔것
    useEffect(() => {
        const testGrid = createEmptyField();
        for(let x = 0; x < LINE.COLS - 1; x++) {
            // 마음대로 재배치 하는법
            // [줄(세로)][칸(가로)] -> [0 ~ 19] [0 ~ 9] 사이면 됨
            // = 뒤에 원하는 색깔 코드 넣기
            testGrid[19][0] = 'blue';
            testGrid[19][1] = 'orange';
        }
    })

    return (
        <div className='tetra_grid_layout'>
            <div className='tetra_grid'
                style={{
                    gridTemplateColumns: `repeat(${LINE.COLS}, 1fr)`,
                    gridTemplateRows: `repeat(${LINE.ROWS}, 1fr)`}}>
                        {grid.map((row, rowIdx) => row.map((cell, colIdx) => {
                            let cellValue = cell;
                            // 블럭이 이 위치에 있는지 확인
                            if(currentBlock && currentBlock.shape) {
                                const { shape, color } = currentBlock;
                                const { x, y } = blockPosition;

                                for(let i = 0; i < shape.length; i++) {
                                    for(let j = 0; j < shape[i].length; j++) {
                                        if(shape[i][j] && rowIdx === y + i && colIdx === x + j) {
                                            cellValue = color ?? 'black';
                                        }
                                    }
                                }
                            }

                            // Cell div
                            return (
                                <div key={`${rowIdx}=${colIdx}`}
                                    className='tetra_cell' style={{ backgroundColor: cellValue ? cellValue : 'transparent'}} />
                            );
                        }))}
                    </div>
        </div>
    );
}

export default SandwichField;