// Redux
import { Provider } from 'react-redux';
import './App.css';

import SharkController from './process/SharkController';

function App() {
  return (
    <Provider store={store}>
      <SharkController />
    </Provider>
  );
}

export default App;
