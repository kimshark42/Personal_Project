// 페이지를 넘기는 상수 모음

const PAGE = {

    MAIN_PAGE : 'main_page',  // 메인 페이지
}

export default PAGE;