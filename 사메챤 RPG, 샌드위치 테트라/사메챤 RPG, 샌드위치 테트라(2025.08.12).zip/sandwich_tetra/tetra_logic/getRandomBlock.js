import { TETRAS } from "../tetra/TETRAS";

function getRandomBlock() {
    console.log('getRandomBlock 작동함!!');  // 로그
    const keys = Object.keys(TETRAS).filter(k => k !== '0');  // 빈 블럭 제외하기
    const randomkey = keys[Math.floor(Math.random()*keys.length)];
    return TETRAS[randomkey];
}

export default getRandomBlock;