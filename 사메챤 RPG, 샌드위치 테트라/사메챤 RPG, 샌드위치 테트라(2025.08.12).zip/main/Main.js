import PAGE from "../process/PAGE";

function Main({changePageMode}) {
    return (
        <div className="main">
            <div className="main_button">
                <button>버튼 1</button>
                <button>버튼 2</button>
            </div>
        </div>
    );
}

export default Main;