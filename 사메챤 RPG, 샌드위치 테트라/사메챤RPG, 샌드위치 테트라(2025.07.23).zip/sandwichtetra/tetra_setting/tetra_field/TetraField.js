import { useEffect, useState } from 'react';

import './TetraField.css';

import TETRAS from '../TETRAS.js';

// 가로세로 격자
const ROWS = 20;
const COLS = 10;

// 빈 필드 생성
const createEmtyField = () => Array.from({ length: ROWS }, () => Array(COLS).fill(0));

function TetraField() {

    // 필드 격자 상태
    const [grid ,setGrid] = useState(createEmtyField);
    // 블럭 상태
    const [currentBlock, setCurrentBlock] = useState(null);
    const [blockPosition, setBlockPosition] = useState({ x: 0, y: 0 });

    // 블럭을 무작위로 가져옴
    const getRandomBlock = () => {
        //로그
        // console.log('getRandomBlock 작동함');
        const keys = Object.keys(TETRAS);
        const randKey = keys[Math.floor(Math.random()*keys.length)];
        return TETRAS[randKey].shape;
    };

    // 새로운 블럭 스폰
    const spawmBlock = () => {
        // const block = getRandomBlock();
        const block = TETRAS['T']?.shape;

        // 오류 확인 로그
        // if (block || Array.isArray(block) || block[0]) {
        //     console.log('블럭 모양이 유효하다',block);
        //     return;
        // }
        // 로그
        // console.log(block, '블럭 떨어짐!!');

        const x = Math.floor((COLS - block[0].length) / 2);  // 중앙 정렬
        const y = 0;
        setCurrentBlock(block);
        setBlockPosition({ x, y });

        // 기존 필드에 블럭 덮기 <- 이게 문제였음 이제 블럭 잘 떨어져서 고정됨 "랜덤으로"
        // const newGrid = createEmtyField();
        // for (let i = 0; i < block.rowSize; i++) {
        //     for (let j = 0; j < block[i].rowSize; j++) {
        //         if (block[i][j]) {
        //             newGrid[y + i][x + j] = 1;
        //         }
        //     }
        // }
        // setGrid(newGrid);
    };

    const spawmNextBlock = () => {
        const newBlock = getRandomBlock();
        setCurrentBlock(newBlock);
        setBlockPosition({ x: 4, y: 0 });

        // 새 블럭이 처음부터 충돌하면 게임 오버
        if (checkCollosion(newBlock, { x: 4, y: 0 }, grid)) {
            alert("꽈당큐...");
            // resetGame();
        }
    }

    // 바닥 충돌 감지
    const checkCollosion = (tetromino,position, grid) => {
        // 로그
        // console.log ('바닥 충돌 감지 작동함', tetromino, position, grid);
        for (let y = 0; y < tetromino.length; y++) {
            for (let x = 0; x < tetromino[y].length; x++) {
                if (tetromino[y][x] !== 0) {
                    const newY = position.y + y;
                    const newX = position.x + x;
                    // 필드 범위를 벗어나거나, 이미 찬 칸과 겹치면 충돌
                    if (newY >= grid.length || newX < 0 || newX >= grid[0].length || grid[newY][newX] !== 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    };

    // 줄 삭제 로직
    const clearFullLines = (grid) => {
        const newGrid = grid.filter(row => row.some(cell => cell === 0));  // 꽉찬 줄 제외
        const linesCleared = ROWS - newGrid.length;  // 줄 몇개 제거 되었는지

        // 위에서 줄 추가
        const emptyRows = Array.from({ length: linesCleared }, () => Array(COLS).fill(0));
        return [...emptyRows,...newGrid];
    };

    // 랜덤으로 블럭 랜더링
    useEffect(() => {spawmBlock();},[]);
    
    // 블럭 드롭
    useEffect(() => {
        const interval = setInterval(() => {
            const nextY = blockPosition.y + 1;
            const nextPos = { ...blockPosition, y: nextY };

            const isCollide = checkCollosion(currentBlock, nextPos, grid);

            if (isCollide) {
                // 로그
                // console.log('바닥에 닿음!!');
                // 블럭을 필드에 고정
                const newGrid = [...grid.map(row => row)];
                for (let y = 0; y < currentBlock.length; y++) {
                    for (let x = 0; x < currentBlock[y].length; x++) {
                        if (currentBlock[y][x]) {
                            const gy = blockPosition.y + y;
                            const gx = blockPosition.x + x;
                            if (gy >= 0 && gy < ROWS && gx >= 0 && gx < COLS) {
                                newGrid[gy][gx] = currentBlock[y][x];
                            }
                        }
                    }
                }
                setGrid(clearFullLines(newGrid));
                // 다음 블럭으로 교체
                spawmBlock();
            } else {
                setBlockPosition(nextPos);
            }
        }, 500);
        return () => clearInterval(interval);
    }, [blockPosition, currentBlock, grid]);
    
    // 바닥 미리 깔아둔것
    useEffect(() => {
        const testGrid = createEmtyField();
        for (let x = 0; x < COLS - 1; x++) {
            // 맘대로 재배치 하는법
            // [줄(세로)][칸(가로)] -> 0~19 0~9 사이면 됨
            testGrid[19][0] = 1;
            testGrid[19][1] = 1;
            testGrid[19][2] = 1;
            testGrid[19][6] = 1;
            testGrid[19][7] = 1;
            testGrid[19][8] = 1;
            testGrid[19][9] = 1;
        }
        setGrid(testGrid);
    }, []);

    return (
        <div className="tetra_field_test">
            <div className="tetra_grid"
                style={{
                    gridTemplateColumns: `repeat(${COLS}, 1fr)`,
                    gridTemplateRows: `repeat(${ROWS}, 1fr)` }}>
                {grid.map((row, rowIdx) => row.map((cell, colIdx) => {
                    let cellValue = cell;
                    // 블럭이 이 위치에 있는지 확인
                    if (currentBlock) {
                        const { x, y } = blockPosition;
                        for (let i = 0; i < currentBlock.length; i++) {
                            for (let j = 0; j < currentBlock[i].length; j++) {
                                if (currentBlock[i][j] && rowIdx === y + i && colIdx === x + j) {
                                    cellValue = 1;
                                }
                            }
                        }
                    }
                    return (
                        <div key={`${rowIdx}-${colIdx}`}
                        className='tetra_cell' style={{ backgroundColor: cellValue ? 'red' : 'transparent' }} />
                    )
                }))}
            </div>
        </div>
    );
}

export default TetraField;