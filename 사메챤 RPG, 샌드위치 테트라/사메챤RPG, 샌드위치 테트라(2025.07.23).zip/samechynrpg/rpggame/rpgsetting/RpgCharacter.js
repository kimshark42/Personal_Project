function RpgCharacter({ changePageMode }) {
    return (
        <div>
            테스트용 div
        </div>
    );
}

export default RpgCharacter;