// 페이지 넘기는 상수 모음

const PAGE = {
    // 페이지 변경및 각종 시스템
    MAIN_SYSTEM : 'system',

    // 메인페이지에서 넘어가는 페이지 모음
    MAIN_PAGE : 'main_page',  // 메인페이지
    SAMECHAN_RPG : 'samechan_rpg',  // 사메챤 RPG
    SANDWICH_TETRA : 'sandwich_tetra',  // 샌드위치 테트라
    API : 'api',  // API

    // 샌드위치 테트라 관련 페이지
    TEST_TETERES : 'test_teteres',  // 테트리스 개발 테스트용 페이지
    TETRA_GAME : 'tetra_game',  // 테트리스 인 게임 화면

    // 사메챤 RPG 관련 페이지
    SAMECHAN_RPG_GAME : 'samechan_rpg_game',  // Text RPG 게임 메인화면
};

export default PAGE;