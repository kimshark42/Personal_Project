import './App.css';

import Controller from "./process/SharkController.js";

function App() {
    return (
        <div>
            <Controller />
        </div>
    );
}
export default App;