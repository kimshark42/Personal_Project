import { useState } from "react";

import { PAGE } from "./PAGE";
import ErrorPage from "../error/ErrorPage";
import Main from "../main/Main";
import RpgMain from "../game/rpg/rpg_main/RpgMain";

// 페이지 전환용 코드
function SharkController() {

    // 여러 페이지 상태를 배열로 분리
    var [currentPage, setCurrentPage] = useState(PAGE.MAIN);  // 기본 페이지 상태를 메인으로 설정
    
    // 페이지를 바꾸기 위한 도우미 함수
    function changePageMode(page) {
        // PAGE.js 안에 존재하지 않는 값이면 에러 페이지로 이동
        if(!Object.values(PAGE).includes(page)) {
            setCurrentPage("ERROR_PAGE");
        } else {
            setCurrentPage(page);
        }
    }

    // 페이지륻릉 객체 매핑 방식으로 변경
    const pages = {
        [PAGE.MAIN] : <Main changePageMode={changePageMode} />,

        // 샌드위치 테트라
        // [PAGE.SANDWICH_TETRA]: <SandwichMain changePageMode={changePageMode} />,
        
        // 사메챤 RPG
        [PAGE.SAMECHAN_RPG] : <RpgMain changePageMode={changePageMode} />,
    }

    return <div>{pages[currentPage] || <ErrorPage changePageMode={changePageMode} />}</div>;
}

export default SharkController