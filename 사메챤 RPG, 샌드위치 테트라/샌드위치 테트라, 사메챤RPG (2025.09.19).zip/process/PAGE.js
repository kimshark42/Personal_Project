// 페이지 넘기는 상수 모음
const PAGE = {

    // 설정 관련 페이지
    ERROR_PAGE: 'ERROR_PAGE',

    // 메인 페이지
    MAIN: 'MAIN',  // 메인 페이지
    SANDWICH_TETRA: 'SANDWICH_TETRA',  // 샌드위치 테트라
    SAMECHAN_RPG: 'SAMECHAN_RPG',  // 사메챤 RPG
}

export { PAGE };