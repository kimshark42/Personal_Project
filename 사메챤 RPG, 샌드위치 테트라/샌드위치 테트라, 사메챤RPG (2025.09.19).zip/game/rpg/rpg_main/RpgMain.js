import { useState } from "react";
import GameMain from "../../../GameMain";

import './RpgMain.css';

import { PAGE } from "../../../process/PAGE";
import RpgRealClock from "../rpg_util/clock/RpgRealClock";

// RPG 메인
function RpgMain({ changePageMode }) {

    // 사이드바 펼치고 접기
    const [isOpen, setIsOpen] = useState(false);

    // 버튼들을 배열로 정리
    const levels = [ "기본", "중급", "고급", "무작위" ];
    const characters = [ "캐릭터 생성", "도전 과제", "전투 부분(갤러리)" ];

    // 버튼에 따라 난이도 조절
    const [selectedLevel, setSelectedLevel] = useState("기본");

    const levelDescriptions = {
        기본: "난이도를 기본 값으로 지정합니다 NPC들과 몬스터들은 무작위로 결정됩니다. 초심자에게 추천합니다",
        중급: "난이도를 중급값으로 지정합니다 NPC들과 몬스터들은 무작위로 결정되며 추가 아이템 및 제약이 생깁니다. 중급닌자 이상에게만 추천합니다",
        고급: "모든 설정을 플레이어가 지정한 값으로 플레이합니다. 즐기세요!!",
        무작위: "모든 설정이 무작위로 변경됩니다.",
    };

    return (
        <div>
            <div className='rpg_layout'>
            {/* RpgComponent */}
            {/* sidbar */}
            <div className='tooggle_button' onClick={() => setIsOpen(!isOpen)}>
                {isOpen ? '🦈' : '🐟' }
            </div>
            <div className={`sidebar ${isOpen ? "closed" : ""}`}>
            <aside>
                {/* 사이드바 내부 */}
                <div className='rpg_main-sidebar_logo'></div>
                <p>Version 0.0.0</p>
                <RpgRealClock />
                <div className='rpg_main-sidebar_button'>
                    {/* 사이드바 버튼 모음 */}
                    <button>세이브(로드)</button>
                    <button>도전과제</button>
                    <button>옵션</button>
                    <button onClick={() => changePageMode(PAGE.MAIN)}>게임 종료</button>
                </div>
            </aside>
            </div>
            {/* 사이드바 종료 */}
            {/* </div> */}
            {/* 사이드바 버튼 종료 */}
            <main>
                {/* 메인화면 */}
                <div className='rpg_main-main_logo'>메인 로고</div>
                <h1>적당한 게임 설명</h1>
                <p>몇가지 세부 사항 및 주의 (글자 회색및 작게)</p>
                <div className='rpg_main-main_button-height'>
                    {/* 게임 난이도 선택 버튼들 */}
                    {levels.map((level, i) => (
                    <button key={i} onClick={() => setSelectedLevel(level)} className={selectedLevel === level ? "active" : ""}>
                            {level}
                    </button>))}
                </div>
                <hr/>
                <div className='rpg_main-main_button-row'>
                    캐릭터 생성 관련 버튼들
                    {characters.map(chara => (<button key={chara}>{chara}</button>))}
                </div>
                <div className='rpg_main-main-level_box'>
                    {selectedLevel}: {levelDescriptions[selectedLevel]}
                    <p>대부분의 설정은 나중에 당신의 집에서 변경 가능합니다. 도전과제 부스트는 게임 시작 이후에 변경할 수 없습니다!!</p>
                </div>
                <selection className='rpg_main-save_box'>
                    <label>세이브 이름: <input type="text" placeholder="입력하세요"/></label>
                </selection>
                <div className='rpg_main-game_start'>
                    <label>
                        <span className='rpg_main-game_start_text'>
                            현재 설정: <span className='rpg_main-game_start_text-level'>{selectedLevel}</span></span>
                         {/* todo - 이거 링크처럼 다는것도 고민하기 */}
                        <button onClick={() => changePageMode(PAGE.MAIN)}>(1) 게임을 시작하지</button>
                    </label>
                </div>
            </main>
            RpgComponent 종료
            </div>
            {/* <GameMain /> */}
        </div>
    );
}

export default RpgMain;