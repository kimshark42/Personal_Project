import { useEffect, useState } from "react";

import './RpgRealClock.css';

// 사이드바 시계
function RpgRealClock() {

    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);  // 컴포넌트 언마운트 시 정리
    })

    // 날짜
    const month = String(time.getMonth() + 1).padStart(2, "0");  // 월
    const day = String(time.getDate()).padStart(2, "0");  // 일

    // 시/분
    let hours = time.getHours();  // 시
    const ampm = hours >= 12 ? "PM" : "AM";  // 오전/오후
    hours = hours % 12 || 12;  // 12 시간제
    const hourStr = String(hours).padStart(2, "0");  // 시 (표기)
    const minutes = String(time.getMinutes()).padStart(2,"0");  // 분

    // 요일 (영문 약자)
    const days = [ "Sun", "Mon", "Tue", "Wen", "Thu", "Fri", "Sat" ];
    const weekday = days[time.getDay()];

    // 최종 출력 09.18 PM 05:28 📆Thu 이런식으로 출력됨
    const formatDay = `${month}.${day}`;
    const formatTime = `${ampm} ${hourStr}:${minutes}`;
    const formatWeek = `📆${weekday}`;
    
    // 2025.09.18 05:26:44 이런식으로 출력됨 (이건 이제 안씀)
    const lastDaysWrite = time.toLocaleDateString("ko-KR", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
    });

    return (
        <div className='rpg_main-sidebar_clock'>
            {/* <span>{formatDay}</span> */}
            {/* <span>{formatTime}</span> */}
            {/* <span>{formatWeek}</span> */}
            {lastDaysWrite}
        </div>
    );
}

export default RpgRealClock;