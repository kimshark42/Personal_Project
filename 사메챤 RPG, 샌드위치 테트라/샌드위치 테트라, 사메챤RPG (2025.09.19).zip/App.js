import './App.css';
import GameMain from './GameMain';
import SharkController from './process/SharkController';

function App() {
  return (
    <div>
      <SharkController />
      {/* <GameMain/>
      게임 페이지
      <br/>
      메인 페이지, 게임 페이지, 게임 설정 페이지(캐릭터 메이킹) 세이브 파일 페이지 */}
    </div>
  );
}

export default App;
