import { PAGE } from '../process/PAGE';
import './ErrorPage.css';

// 에러 페이지
function ErrorPage({ changePageMode }) {
    return (
        <div className='error_layout'>
            <div className='error_line'>
                <div className='error_content'>
                    <div className='error_message'>
                        <h1>잘못된 페이지 입니다.</h1>
                        <button onClick={() => changePageMode(PAGE.MAIN)}>메인 페이지로 돌아가기</button>
                    </div>
                    <div className='error_imge'>
                        <div className='error_img'>에러 이미지</div>
                        <p>문 열어!!!!!!!!</p>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ErrorPage