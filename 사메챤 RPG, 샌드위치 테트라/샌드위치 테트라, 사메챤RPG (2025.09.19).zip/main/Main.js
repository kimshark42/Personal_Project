import './Main.css';

import { PAGE } from "../process/PAGE";

// 메인 화면
function Main({ changePageMode }) {

    // 배열 기반으로 버튼 렌더링
    const buttons = [
        // { label: "샌드위치 테트라", page: PAGE.SANDWICH_TETRA },
        { label: "사메챤 RPG", page: PAGE.SAMECHAN_RPG },
        { label: "에러용 페이지", page: "NOT_EXISTING_PAGE" },
    ];

    return (
        <div className='main'>
            <div className='main_button'>
                {buttons.map(btn => (
                    <button key={btn.label} onClick={() => changePageMode(btn.page)}>{btn.label}</button>
                ))}
            </div>
        </div>
    );
}

export default Main;