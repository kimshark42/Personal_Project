/*
todo

-일단 디자인 작업부터
-> 위치 조정
-> 다음 할것 디자인
-> 다음 할것 시간 가져오기

*/

import { useEffect, useState } from 'react';
// import './GameMain.css';

// 메인화면
function GameMain() {

    // 시계
    // todo - 나중에 분리하기
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);  // 컴포넌트 언마운트 시 정리
    })

    const formatted = time.toLocaleDateString("ko-KR", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
    });


    return (
        <div className='game_main_layout'>
            {/* 게임 화면 전체 틀 */}
            <aside>
                {/* 사이드 바 */}
                <div className='main_side_logo'>사이드 로고</div>
                <p>Version 0.0.0</p>
                <div className='main_clock'>
                    <span>{formatted}</span>
                    {/* <span>2000</span> */}
                    {/* <span>00:00</span> */}
                    {/* <span>📆 Wen</span> */}
                </div>
                <div className='main_side_button'>
                    {/* 사이드바 버튼 모음 */}
                    <button>세이브(로드)</button>
                    <button>도전과제</button>
                    <button>게임 옵션</button>
                    <button>게임 종료</button>
                </div>
            </aside>
            <main>
                {/* 메인 화면 */}
                <div className='main_big-logo'>메인 로고</div>
                <div>게임 설명</div>
                <div>
                    게임 난이도 선택 버튼들
                    <button>기본</button>
                    <button>중급</button>
                    <button>어려움</button>
                    <button>무작위</button>
                </div>
                <hr/>
                <div>
                    캐릭터 생성 관련 버튼들
                    <button>캐릭터 생성</button>
                    <button>도전과제</button>
                    <button>전투 부분(갤러리)</button>
                </div>
                <div>난이도에 맞춘 설명</div>
                <label>세이브<input type="text"/></label>
                <label>게임을 시작하지<button>게임 시작(이거 링크처럼 다는것도 고민)</button></label>
            </main>
        </div>
    );
}

export default GameMain;