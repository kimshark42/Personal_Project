import './TetraField.css';

import useTetraState from '../useTetraState.js';

import getRandomBlock from '../tetra_logic/getRandomBlock.js'
import { LINE, TETRAS } from '../TETRA.js';
import checkCollision from '../tetra_logic/checkCollision.js'
import { useEffect } from 'react';
import clearFullLines from '../tetra_logic/clearFullLines.js';
import createEmptyField from './createEmptyField.js';

// 필드 생성
function TetraField() {

    // 각종 상태 공유
    const {
        grid, setGrid,
        currentBlock, setCurrentBlock,
        blockPosition, setBlockPosition,
        isGameOver, setIsGameOver
    } = useTetraState();

    // 게임 오버 로직 ->  todo 이건 나중에 분리해서 겜 시작 버튼으로 옮길것
    const gameOver = (() => {
        setIsGameOver(true);
        alert('꽈당큐...');
    });

    // 게임 재시작
    const resetGame = () => {
        // setGrid(initGrid())
    }

    // 새로운 블럭 스폰
    const spawnBlock = () => {
        // const block = getRandomBlock();
        const block = TETRAS['O'];
        const { shape, color } = block;

        // 중앙 정렬
        const x = Math.floor((LINE.COLS - shape[0].length) / 2);
        const y = 0;

        const isBlocked = checkCollision({ tetromino: shape, position: { x, y }, grid});
        if (isBlocked) {
            gameOver();
        } else {
            setCurrentBlock({ shape, color });
            setBlockPosition({ x, y });
        }
    };

    // 필드에 랜덤으로 블럭 랜더링
    useEffect(() => {spawnBlock();},[]);

    // 블럭 브롭
    useEffect(() => {
        if(isGameOver) return;

        const interval = setInterval(() => {
            const nextY = blockPosition.y + 1;
            const nextPos = { ...blockPosition, y: nextY };

            const isCollide = checkCollision({
                tetromino: currentBlock.shape,
                position: nextPos,
                grid
            });

            if(isCollide) {
                // 블럭을 필드에 고정
                const newGrid = [...grid.map(row => row)];
                for (let y = 0; y < currentBlock.shape.length; y++) {
                    for (let x = 0; x < currentBlock.shape[y].length; x++) {
                        if (currentBlock.shape[y][x]) {
                            const gy = blockPosition.y + y;
                            const gx = blockPosition.x + x;
                            if(grid[gy]?.[gx] !== 0) {
                                gameOver();
                                return;
                            }
                            if(gy >= 0 && gy < LINE.ROWS && gx >= 0 && gx < LINE.COLS) {
                                newGrid[gy][gx] = currentBlock.shape[y][x];
                            }
                        }
                    }
                }
                setGrid(clearFullLines(newGrid));
                // 줄 삭제 이후 다음 블럭으로 교체
                spawnBlock();
            } else {
                setBlockPosition(nextPos);
            }
        }, 500);  // 500ms 마다 떨어짐, (5초에 한칸씩)
        return () => clearInterval(interval);
    }, [blockPosition, currentBlock, grid, isGameOver]);

    // 바닥에 미리 깔아둔것
    useEffect(() => {
        const testGrid = createEmptyField();
        for(let x = 0; x < LINE.COLS - 1; x++) {
            // 마음대로 재배치 하는법
            // [줄(세로)[칸(가로)]] -> 0 ~ 19, 0 ~ 9 사이값을 넣고 = 뒤에 원하는 색깔 코드 넣기
            testGrid[19][0] = 'bule';
            testGrid[19][1] = 'orange';
            testGrid[19][2] = 'greenyellow';
            testGrid[19][3] = 'black';
            testGrid[19][6] = 'red';
            testGrid[19][7] = 'violet';
            testGrid[19][8] = 'yellow';
            testGrid[19][9] = 'aqua';

            testGrid[18][9] = 'mediumturquoise';
            testGrid[18][8] = 'deepskyblue';
            testGrid[18][7] = 'fuchsia';
            testGrid[18][6] = 'indigo';
            testGrid[18][3] = 'teal';
            testGrid[18][2] = 'olivedrab';
            testGrid[18][1] = 'slategray';
            testGrid[18][0] = 'lime';
        }
        setGrid(testGrid);
    }, []);

    return (
        <div className='tetra_grid'
            style={{
                gridTemplateColumns: `repeat(${LINE.COLS}, 1fr)`,
                gridTemplateRows: `repeat(${LINE.ROWS}, 1fr)`}}>
            {grid.map((row, rowIdx) => row.map((cell, colIdx) => {
                let cellValue = cell;
                // 블럭이 이 위치에 있는지 확인
                if (currentBlock && currentBlock.shape) {
                    const { shape, color } = currentBlock;
                    const { x, y } = blockPosition;

                    for(let i = 0; i < shape.length; i++) {
                        for(let j = 0; j < shape[i].length; j++) {
                            if(shape[i][j] && rowIdx === y + i && colIdx === x + j) {
                                cellValue = color ?? 'black';
                            }
                        }
                    }
                }
                return (
                    <div key={`${rowIdx}-${colIdx}`}
                    className='tetra_cell' style={{ backgroundColor: cellValue ? cellValue : 'transparent'}}/>
                );
            }))}
        </div>
    );
}

export default TetraField;