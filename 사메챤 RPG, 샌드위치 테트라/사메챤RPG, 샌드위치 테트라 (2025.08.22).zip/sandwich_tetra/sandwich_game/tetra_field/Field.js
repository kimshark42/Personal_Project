import styled from 'styled-components';
import { LINE } from '../TETRA';
import useTetraState from '../useTetraState';
import Cell from './Cell';

// styled 로 함 해봤는데 못하겠음
const StyledField = styled.div`
    display: grid;
    grid-template-rows: repeat(${props => props.rows}, 1fr);
    grid-template-columns: repeat(${props => props.cols}, 1fr);
    gap: 2px;
    // background-color: white;
    padding: 10px;
    border-radius: 6px;

    border-left: 3px solid black;
    border-right: 3px solid black;
    border-bottom: 3px solid black;
    border-top: none;
    `

function Field() {

    const { grid } = useTetraState();

    return (
        <StyledField rows={LINE.ROWS} cols={LINE.COLS}>
            {grid.map((row, rowIdx) => row.map((cell, colIdx) => {
                return <Cell key={`${rowIdx}-${colIdx}`} type={String(cell[0])}></Cell>
            }))}
        </StyledField>
    );
}

export default Field;