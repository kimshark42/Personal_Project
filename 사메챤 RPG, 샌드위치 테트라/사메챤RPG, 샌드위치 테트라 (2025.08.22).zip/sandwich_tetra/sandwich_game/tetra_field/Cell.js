import React from "react";
import styled from "styled-components";
import { TETRAS } from "../TETRA";

// styled 스타일로 한번 해본건데 역량이 딸려서 활용을 제대로 못함 패스
const StyledCell = styled.div`
    border: ${({ border }) => border || '1px solid blak' };
    box-sizing: border-box;
    // background-color: ${({ color }) => color || 'white' };
    aspect-ratio: 1 / 1;
    width: 100%;
    height: 100%; `;

const Cell = ({ type }) => {

    const { color, border } = TETRAS[type] || TETRAS[0]

    return (
        <StyledCell type={type} color={color} border={border}><div></div></StyledCell>
    );
}

export default React.memo(Cell);