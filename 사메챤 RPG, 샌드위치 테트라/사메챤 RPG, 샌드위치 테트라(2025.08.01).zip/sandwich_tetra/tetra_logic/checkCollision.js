// 바닥및 블럭끼리의 충돌 감지
const checkCollision = ({ tetromino, position, grid }) => {
    // 로그
    if (!Array.isArray(tetromino) || !tetromino.length) {
        console.log('tetromino가 잘못됨!!:', tetromino)
        return false;
    }

    for(let y = 0; y < tetromino.length; y++) {
        for(let x = 0; x < tetromino[y].length; x++) {
            if(tetromino[y][x] !== 0) {
                const newY = position.y + y;
                const newX = position.x + x;
                // 필드 범위를 벗어나거나, 이미 찬 칸과 겹치면 충돌
                if (newY >= grid.length || newX < 0 || newX >= grid[0].length || grid[newY][newX][1] !== 'clear') {
                    return true;
                }
            }
        }
    }
    return false;
}

export default checkCollision;