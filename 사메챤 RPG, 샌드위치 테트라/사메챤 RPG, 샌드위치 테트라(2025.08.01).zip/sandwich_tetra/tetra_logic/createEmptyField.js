import { LINE } from "../tetra/TETRAS";

// 빈 필드 생성
const createEmptyField = () => {return Array.from({ length: LINE.ROWS }, () => Array(LINE.COLS).fill([ 0, 'clear' ]));}

export default createEmptyField;