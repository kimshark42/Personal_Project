import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

import checkCollosion from './checkCollision.js';
import createEmptyField from './createEmptyField.js';

const useField = () => {
    const grid = useSelector(state => state.tetraState.grid);  // 필드
    // 이번 턴에 지운 줄 수(점수)
    const blockPosition = useSelector(state => state.tetraState.blockPosition);  // 블럭 위치
    
}
export default useField;
