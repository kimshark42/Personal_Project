import { TETRAS } from "../tetra/TETRAS";

function getRandomBlock() {
    console,log('getRanddomBlock 작동함!!');  // 로그
    const keys = Object.keys(TETRAS);
    const randomKey = keys[Math.floor(Math.random()*keys.length)];
    return TETRAS[randomKey];
}

export default getRandomBlock;