// 테트리스 모양 모음
const TETRAS = {
    I: {
        shape: [
            [ 0, 0, 0, 0 ],
            [ 0, 0, 0, 0 ],
            [ 'I', 'I', 'I', 'I' ],
            [ 0, 0, 0, 0 ]
        ],
        color: 'aqua',
        border: 'rgba(0, 0, 0, 0.8)'
    },
    O: {
        shape: [
            [ 0, 0, 0, 0 ],
            [ 0, 'O', 'O', 0 ],
            [ 0, 'O', 'O', 0 ],
            [ 0, 0, 0, 0 ]
        ],
        color: 'yellow',
        border: 'rgba(0, 0, 0, 0.8)'
    },
    T: {
        shape: [
            [ 'T', 'T', 'T', 0 ],
            [ 0, 'T', 0, 0 ],
            [ 0, 'T', 0, 0 ],
            [ 0, 0, 0, 0 ]
        ],
        color: 'violet',
        border: 'rgba(0, 0, 0, 0.8)'
    },
    Z: {
        shape: [
            [ 0, 0, 0, 0 ],
            [ 'Z', 'Z', 0, 0 ],
            [ 0, 'Z', "Z", 0 ],
            [ 0, 0, 0, 0 ]
        ],
        color: 'red',
        border: 'rgba(0, 0, 0, 0.8)'
    },
    S: {
        shape: [
            [ 0, 0, 0, 0 ],
            [ 0, 0, 'S', 'S' ],
            [ 0, 'S', 'S', 0 ],
            [ 0, 0, 0, 0 ]
        ],
        color: 'greenyellow',
        border: 'rgba(0, 0, 0, 0.8)'
    },
    L: {
        shape: [
            [ 0, 'L', 0, 0 ],
            [ 0, 'L', 0, 0 ],
            [ 0, 'L', 0, 0 ],
            [ 0, 'L', 'L', 0 ]
        ],
        color: 'orange',
        border: 'rgba(0, 0, 0, 0.8)'
    },
    J: {
        shape: [
            [ 0, 0, 'J', 0 ],
            [ 0, 0, 'J', 0 ],
            [ 0, 0, 'J', 0 ],
            [ 0, 'J', 'J', 0 ]
        ],
        color: 'blue',
        border: 'rgba(0, 0, 0, 0.8)'
    },
}

const LINE = {

    // 가로
    ROWS: 20,

    // 세로
    COLS: 10
}

export { TETRAS, LINE };