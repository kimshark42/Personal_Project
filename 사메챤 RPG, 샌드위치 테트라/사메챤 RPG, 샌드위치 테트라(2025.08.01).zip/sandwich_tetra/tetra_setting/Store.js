import { configureStore } from "@reduxjs/toolkit";
import tetraState from "./tetraState";

const store = configureStore({
    reducer: {
        tetraState: tetraState.reducer,
    }
});

export default store;