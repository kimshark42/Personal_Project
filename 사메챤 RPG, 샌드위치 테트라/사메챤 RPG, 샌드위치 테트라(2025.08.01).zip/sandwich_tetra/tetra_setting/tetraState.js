import { createSlice } from "@reduxjs/toolkit";

import createEmptyField from "./createEmptyField.js";

const initialState = {
    grid: createEmptyField(),
    currentBlock: { shape: [], color: ''},
    blockPosition: { x: 0, y: 0 },
    isGameOver: false
};

const tetraState = createSlice({
    name: "tetraState",
    initialState,
    reducers: {
        setGrid(state, action) {
            state.grid = action.payload;
        },
        setCrrentBlock(state, action) {
            state.currentBlock = action.payload;
        },
        setBlockPosition(state, action) {
            state.blockPosition = action.payload;
        },
        setIsGameOver(state, action) {
            state.isGameOver = action.payload;
        },
        resetTetraState(state) {
            Object.assign(state, initialState);  // 전체 리셋
        }
    }
});

export const {
    setGrid,
    setCrrentBlock,
    setBlockPosition,
    setIsGameOver,
    resetTetraState
} = tetraState.actions;

export default tetraState;