import { useEffect, useState } from "react";
import Player from "./Player";
import Monster from "./Monster";

function useTextareaOut(advanceTurnCallback) {

    // useState로 저장하는 각 상태

    // 메세지 박스들
    const [messageLog ,setMessageLog] = useState('');  // 메인 화면
    const [gameObjectLog, setGameObjectLog] = useState('');  // 적 몬스터 및 아이템 info
    const [playerInfo, setPlayerInfo] = useState('');  // 플레이어 info
    // 전투 관련
    const [turnCount, setTurnCount] = useState(0);  // 턴 횟수 저장
    const [isBattle, setIsBattle] = useState(true);  // 전투 상태 저장

    // class 인스턴스 생성, useState로 객체가 한번만 생성되게끔 변경
    // 몬스터 및 플레이어
    const [player] = useState(() => new Player("김상어", 70, 11));
    const [slime] = useState (() => new Monster("슬라링", 12, 1));

    // textarea에 text를 누적해서 찍어주는 함수
    const tx = (text) => {setMessageLog(prev => prev + text);};
    const txPlayerInfo = (text) => {setPlayerInfo(text);};
    const txGameObjectLog = (text) => {setGameObjectLog(text);};

    const procBattleTurn = () => {
        console.log('procBattleTurn 작동함');  // 로그

        // 데미지
        const playerDamage = Math.floor(Math.random()*(player.attack + 1));
        const slimeDamage = Math.floor(Math.random()*(slime.attack + 1));
        slime.receiveDamageMonster(playerDamage);
        player.receiveDamagePlayer(slimeDamage);

        // 턴 진행
        tx(`[턴 ${turnCount + 1}]\n`);
        tx(`당신의 공격! ${playerDamage}의 데미지를 줬습니다.\n`);
        tx(`슬라링의 몸통박치기! ${slimeDamage}를 받았습니다.\n\n`)

        txGameObjectLog(`${slime.info()}`)
        txPlayerInfo(`${player.info()}`)

        setTurnCount(t => t+1);
    };

    const endBattle = () => {
        if(player.currenthp <= 0) {
            console.log('player 패배')  // 로그
            tx(`${player.name}의 HP가 다 되었다! ${player.name}은 눈앞이 캄캄해졌다!`);
            setIsBattle(false);
        } else if (slime.currenthp <= 0) {
            tx(`\n빰빠카빰~! ${slime.name}을 물리쳤다!\n`);
            setIsBattle(false);
        }
    };

    const handleTurn = () => {
        console.log('handleTurn 작동함');  // 로그

        if(!isBattle) {
            console.log('isBattle 작동함')
            tx(`평원은 평화롭습니다...그리고 아무도 없었다.\n`)
            return;
        }
        advanceTurnCallback();
        procBattleTurn();
        endBattle();
    }

    useEffect(() => {txPlayerInfo(`${player.info()}`);},[]);

    return {
        messageLog,
        gameObjectLog,
        playerInfo,
        turnCount,
        handleTurn,
    };
}

export default useTextareaOut;