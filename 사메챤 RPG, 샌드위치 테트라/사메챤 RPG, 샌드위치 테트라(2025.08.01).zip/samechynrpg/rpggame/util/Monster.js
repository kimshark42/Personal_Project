class Monster {
    constructor(name, hp, attack) {
        this.name = name;
        this.maxhp = hp;
        this.currenthp = hp;
        this.attack = attack;
    }

    info() {
        return `[${this.name} HP(${this.currenthp}/${this.maxhp})]`;
    }

    receiveDamageMonster(damage) {
        this.currenthp = Math.max(0, this.currenthp - damage);
    }
}

export default Monster;