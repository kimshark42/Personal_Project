import { useState } from "react";
import createEmptyField from "./createEmptyField";

function useTetraState() {
    const [grid, setGrid] = useState(createEmptyField());  // 필드 격자 상태
    const [currentBlock, setCurrentBlock] = useState({ shape: [], color: '' });  // 블럭 모양
    const [blockPosition, setBlockPosition] = useState({ x: 0, y: 0 });  // 블럭 위치
    const [isGameOver, setIsGameOver] = useState(false);  // 게임오버 상태

    return{
        grid, setGrid,
        currentBlock, setCurrentBlock,
        blockPosition, setBlockPosition,
        isGameOver, setIsGameOver
    };
}

export default useTetraState;