import { useEffect, useState } from "react";

import './TestTeteres.css';

import PAGE from "../process/PAGE";

const TETROMINOS = {
  I: [[ 1, 1, 1, 1 ]],  // ㅡ

  O: [[ 1, 1 ],
      [ 1, 1 ]],  // ㅁ

  T: [[ 0, 1, 0 ],
      [ 1, 1, 1 ]],  // ㅗ

  Z: [[ 1, 1, 0],
      [ 0, 1, 1]],  // Z

  S: [[ 0, 1, 1],
      [ 1, 1, 0]],  // S

  L: [[ 1, 0 ],
      [ 1, 0 ],
      [ 1, 1 ]],  // L
  
  J: [[ 0, 1 ],
      [ 0, 1 ],
      [ 1, 1 ]]  // J
}

// 테트리스 필드 부분
// 테트리스의 필드(격자무늬) 생성
const ROWS = 20;  // 세로줄 갯수
const COLS = 10;  // 가로칸 갯수

// 20x10 칸짜리 배열을 만드는 함수, 0은 빈칸으로 취급
const createEmptyField = () => Array.from({ length: ROWS }, () => Array(COLS).fill(0));

function Field({changePageMode}) {

  // 위에서 만든 빈 필드를 useState로 저장
  const [field, setField] = useState(createEmptyField());
  // 현재 화면에 어떤 블럭이 떨어지고 있는지 useState로 저장
  const [currentBlock, setCurrentBlock] = useState({shape: TETROMINOS.T, position: { x: 3, y: 5 }});

  // 🔽 useEffect도 마찬가지
  useEffect(() => {
  const interval = setInterval(() => {
    const nextPosition = {
      x: currentBlock.position.x,
      y: currentBlock.position.y + 1,
    };

    if (isValidMove(currentBlock.shape, nextPosition, field)) {
      // 유효 → 블록 아래로 이동
      setCurrentBlock(prev => ({
        ...prev,
        position: nextPosition,
      }));
    } else {
      // 불가능 → 필드에 블록 고정시키기
      const newField = [...field.map(row => [...row])]; // 깊은 복사
      currentBlock.shape.forEach((row, y) => {
        row.forEach((cell, x) => {
          if (cell === 1) {
            const fy = currentBlock.position.y + y;
            const fx = currentBlock.position.x + x;
            if (fy >= 0 && fy < newField.length && fx >= 0 && fx < newField[0].length) {
              newField[fy][fx] = 1;
            }
          }
        });
      });

      setField(newField);

      // 새 블록 생성 (간단히 T 블록 반복)
      setCurrentBlock({
        shape: TETROMINOS.T,
        position: { x: 3, y: 0 },
      });
    }
  }, 500);

  return () => clearInterval(interval);
}, [currentBlock, field]);

  // 🔽 렌더링
  return (
    <div>
        <button onClick={()=>changePageMode(PAGE.SANDWICH_TETRA)}>메인페이지로 돌아가기</button>
    <div className="field">
      {field.map((row, y) =>
        row.map((cell, x) => {
          // 블록 shape 크기 체크
          const relY = y - currentBlock.position.y;
          const relX = x - currentBlock.position.x;

          let isBlock = false;
          if (
            relY >= 0 &&
            relY < currentBlock.shape.length &&
            relX >= 0 &&
            relX < currentBlock.shape[0].length
          ) {
            isBlock = currentBlock.shape[relY][relX] === 1;
          }

          const value = isBlock ? 1 : cell;

          return (
            <div
              key={`${x}-${y}`}
              className={`cell ${value !== 0 ? "filled" : ""}`}
            />
          );
        })
      )}
    </div>
    </div>
  );
}

export default Field;

// 블럭이 바닥에 닿으면 필드에 고정시키기
function isValidMove(shape, position, field) {
  for (let y = 0; y < shape.length; y++) {
    for (let x = 0; x < shape[y].length; x++) {
      if (shape[y][x] === 0) continue;
      const newY = position.y + y;
      const newX = position.x + x;

      // 필드 바깥 or 이미 차 있는 칸이라면 실패
      if (
        newY >= field.length || //바닥을 뚫었을때
        newX < 0 || newX >= field[0].length ||  // 좌우 벽 확인
        field[newY][newX] !== 0 // 이미 채워져 있을 때
      ) {
        return false;
      }
    }
  }
  return true;
}