// 페이지 넘기는 상수 모음
const PAGE = {

    // 메인 페이지
    MAIN: 'main',  // 메인 페이지
    SANDWICH_TETRA: 'sandwich_tetra',  // 샌드위치 테트라

    //게임화면
    SANDWICH_GAME: 'sandwich_game',  // 테트리스 게임
}

export { PAGE };