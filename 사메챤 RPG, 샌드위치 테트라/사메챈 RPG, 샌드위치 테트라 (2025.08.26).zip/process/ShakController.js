import { useState } from "react";

import { PAGE } from "./PAGE";
import Main from "../main/Main";
import SandwichMain from "../sandwich_tetra/sandwich_main/SandwichMain";
import SandwichGame from "../sandwich_tetra/sandwich_game/SandwichGame";

function SharkController() {

    // 여러 페이지 상태를 배열로 분리
    var [currentPage, setCurrentPage] = useState(PAGE.MAIN);  // 기본 페이지 상태를 메인으로 설정

    // 페이지를 바꾸기 위한 도우미 함수
    function changePageMode(page){setCurrentPage(page);}

    return (
        <div>
            {/* 기본 페이지를 Main.js로 출력하게끔 세팅 */}
            {currentPage === PAGE.MAIN && <Main changePageMode={changePageMode} />}
            {currentPage === PAGE.SANDWICH_TETRA && <SandwichMain changePageMode={changePageMode} />}

            {/* 샌드위치 테트라 관련 */}
            {currentPage === PAGE.SANDWICH_GAME && <SandwichGame changePageMode={changePageMode} />}
        </div>
    );
}

export default SharkController;