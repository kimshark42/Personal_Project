import './SandwichGame.css';

import { useState } from "react";
import { PAGE } from "../../process/PAGE";

// 임시
function CardTest({sea}) {
    return (
        <div className={`card ${sea}`}>
            {sea}
        </div>
    );
}

function SandwichGame({ changePageMode }) {

    // 임시 배열
    var [cardtest] = useState(['상어','고래상어','문어']);
    const [restartKey, setRestartKey] = useState(0);

    const handleRestart = () => {setRestartKey(prev => prev + 1);}

    return (
        <div className='sandwich_game_layout'>
            <div className='sandwich_game_content'>
                <div className='sandwich_game_grid_body'>
                    TetraField
                </div>
                <div className='sandwich_game_content_buttons'>
                    <div className='sandwich_game_logo'></div>
                    <div className='sandwich_game_test'>
                        <div className='card_test'>{cardtest.map((c)=>(<CardTest sea={c} />))}</div>
                        <button onClick={handleRestart}>재시작</button>
                        <button onClick={() => changePageMode(PAGE.SANDWICH_TETRA)}>이전으로</button>
                    </div>
                </div>
            </div>
            SandwichGame
        </div>
    );
}

export default SandwichGame;