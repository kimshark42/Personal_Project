import PAGE from "../PAGE";

function SandwichMain({changePageMode}) {
    return (
        <div>
            <button onClick={()=>changePageMode(PAGE.MAIN_PAGE)}>메인페이지로 돌아가기</button>
            <div><h1>샌드위치 테트라 시작용 div</h1></div>
            <button onClick={()=>changePageMode(PAGE.TEST_TETERES)}>테스팅용 테트리스</button>
        </div>
    );
}

export default SandwichMain;