import { useEffect, useState } from "react";
import './TestTeteres.css';

import PAGE from "../PAGE";

// 테트리스 블록 형태 정의 (함수 바깥에 위치해야 매 렌더마다 다시 정의되지 않음)
const TETROMINOS = {
  I: [[1, 1, 1, 1]],
  O: [[1, 1], [1, 1]],
  T: [[0, 1, 0], [1, 1, 1]],
};

const ROWS = 20;
const COLS = 10;

const createEmptyField = () =>
  Array.from({ length: ROWS }, () => Array(COLS).fill(0));

function Field({changePageMode}) {
  // 🔽 useState는 컴포넌트 함수의 최상단에서 정의
  const [field, setField] = useState(createEmptyField());
  const [currentBlock, setCurrentBlock] = useState({
    shape: TETROMINOS.T,
    position: { x: 3, y: 5 },
  });

  // 🔽 useEffect도 마찬가지
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBlock((prev) => ({
        ...prev,
        position: { x: prev.position.x, y: prev.position.y + 1 },
      }));
    }, 500);

    return () => clearInterval(interval);
  }, []);

  // 🔽 렌더링
  return (
    <div>
        <button onClick={()=>changePageMode(PAGE.SANDWICH_TETRA)}>메인페이지로 돌아가기</button>
    <div className="field">
      {field.map((row, y) =>
        row.map((cell, x) => {
          // 블록 shape 크기 체크
          const relY = y - currentBlock.position.y;
          const relX = x - currentBlock.position.x;

          let isBlock = false;
          if (
            relY >= 0 &&
            relY < currentBlock.shape.length &&
            relX >= 0 &&
            relX < currentBlock.shape[0].length
          ) {
            isBlock = currentBlock.shape[relY][relX] === 1;
          }

          const value = isBlock ? 1 : cell;

          return (
            <div
              key={`${x}-${y}`}
              className={`cell ${value !== 0 ? "filled" : ""}`}
            />
          );
        })
      )}
    </div>
    </div>
  );
}

export default Field;