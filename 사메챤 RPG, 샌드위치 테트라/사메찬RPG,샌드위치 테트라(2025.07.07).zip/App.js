import { useState } from "react";

import PAGE from "./PAGE";
import Main from "./main/Main";
import Rpgmain from "./samechynrpg/Rpgmain";
import SandwichMain from "./sandwichtetra/SandwichMain";

function App() {
    // 여러 페이지 분리 (사메챤RPG, 샌드위치 테트라, API)
    var [currentPage, setCurrentPage] = useState(PAGE.MAIN_PAGE);

    // 페이지를 바꾸기 위한 도우미 함수
    function changePageMode(page){setCurrentPage(page);}

    // 일종의 컨트롤러의 역할
    return (
        <div>
            {/* 기본 페이지를 Main.js로 기본출력하게끔 세팅 */}
            {currentPage === PAGE.MAIN_PAGE && <Main changePageMode={changePageMode} />}
            {currentPage === PAGE.SAMECHAN_RPG && <Rpgmain changePageMode={changePageMode} />}
            {currentPage === PAGE.SANDWICH_TETRA && <SandwichMain changePageMode={changePageMode} />}
        </div>
    );
}
export default App;