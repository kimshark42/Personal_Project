// 메인화면
// 2025.07.07 일단 메인 화면에서 링크 클릭시 사메챤 RPG와 길드 샌드위치 테트라를 분리 접속 가능하게끔하기 <- 성공

// todo - App.js 에서 있는 컨트롤러를 컨트롤러 전용 js 를 만들어서 관리하기 + TestTeteres로 버튼 클릭시 이동
// todo - RPG 만들기에서 만들어 놓았던 RPG 옮기기

import PAGE from "../PAGE";

function Main({changePageMode}) {
    return (
        <div>
            <button onClick={()=> changePageMode(PAGE.SAMECHAN_RPG)}>사메챤RPG</button>
            <button onClick={()=> changePageMode(PAGE.SANDWICH_TETRA)}>샌드위치 테트라</button>
        </div>
    );
}

export default Main;