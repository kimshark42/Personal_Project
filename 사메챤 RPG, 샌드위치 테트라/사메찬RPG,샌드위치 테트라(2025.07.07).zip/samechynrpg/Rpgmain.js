import './RpgMain.css';

import { useState } from "react";

import PAGE from "../PAGE";

function Rpgmain({changePageMode}) {

    // 사이드바 펼치고 접기
    const [isOpen, setlsOpen] = useState(true);

    return (
        <div className="rpg_main">
            <button className="toggle-button" onClick={()=> setlsOpen(!isOpen)}>➡️</button>
            <aside className={`sidebar ${!isOpen ? "closed" : ""}`}>
                <div className="scroll-content">
                    <p>사이드바 내용</p>
                    <button onClick={()=>changePageMode(PAGE.MAIN_PAGE)}>메인페이지로 돌아가기</button>
                </div>
            </aside>

            <main className="main-content">
                <h1>사메챤 RPG</h1>
            </main>
        </div>
    );
}

export default Rpgmain;