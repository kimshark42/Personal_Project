// 필드 상수 모음

const Field = {
    // 가로
    COLS : 10,

    // 세로
    ROWS : 20
};

export default Field;