import { useEffect, useState } from 'react';

import './TetraField.css';

// import TETRAS from '../TETRAS.js';
import PAGE from '../../../process/PAGE.js';

// 가로세로 격자
import Field from './Field.js';

// 빈 필드 생성
import createEmptyField from './CreateEmptyField.js';
// useState, useEffect
import useFieldState from './useFieldState.js';
import useFieldEffect from './useFeildEffect.js';
import GetRandomBlock from './GetRandomBlock.js';

function TetraField() {

    const {
        grid, setGrid,
        currentBlock, setCurrentBlock,
        blockPosition, setBlockPosition,
        isGameOver, setIsGameOver
    } = useFieldState();

    // useFieldEffect({
    //     blockPosition,
    //     checkCollision,
    //     currentBlock,
    //     grid,
    //     GameOver,
    //     setGrid,
    //     spawmBlock,
    //     setBlockPosition
    // });

    
    // 새로운 블럭 스폰
    const spawmBlock = () => {
        const block = GetRandomBlock();
        // const block = TETRAS['T'];
        const { shape, color } = block;
        // 중앙 정렬
        const x = Math.floor((Field.COLS - shape[0].length) / 2);
        const y = 0;
        setCurrentBlock({ shape, color });
        setBlockPosition({ x, y });
    };

    // 게임오버 로직
    const GameOver = (() => {
        setIsGameOver(true);

        setTimeout(() => {
            alert('꽈당큐...');

            // 필드 초기화
            const emptyGrid = Array.from({ length: Field.ROWS }, () => Array(Field.COLS).fill(0));
            setGrid(emptyGrid);

            setIsGameOver(false);
        }, 0);
        spawmBlock();
    });

    // 바닥 충돌 감지
    const checkCollision = (tetromino, position, grid) => {
        if (!Array.isArray(tetromino) || !tetromino.length) {
            // 로그
            // console.log('tetromino가 잘못됨!!:', tetromino)
            return false;
        }

        for (let y = 0; y < tetromino.length; y++) {
            for (let x = 0; x < tetromino[y].length; x++) {
                if (tetromino[y][x] !== 0) {
                    const newY = position.y + y;
                    const newX = position.x + x;
                    // 필드 범위를 벗어나거나, 이미 찬 칸과 겹치면 충돌
                    if (newY >= grid.length || newX < 0 || newX >= grid[0].length || grid[newY][newX] !== 0) {
                        // 로그
                        // console.log(`충돌 발생 at (${newY}, ${newX})`);
                        return true;
                    }
                }
            }
        }
        return false;
    };

    // 줄 삭제 로직
    const clearFullLines = (grid) => {
        const newGrid = grid.filter(row => row.some(cell => cell === 0));  // 꽉찬 줄 제외
        const linesCleared = Field.ROWS - newGrid.length;  // 줄 몇개 제거 되었는지

        // 위에서 줄 추가
        const emptyRows = Array.from({ length: linesCleared }, () => Array(Field.COLS).fill(0));
        return [...emptyRows,...newGrid];
    };

    // 랜덤으로 블럭 랜더링
    useEffect(() => {spawmBlock();},[]);
    
    // 블럭 드롭
    useEffect(() => {
        // 로그
        // console.log('블럭 드롭 작동함!!');

        const interval = setInterval(() => {
            const nextY = blockPosition.y + 1;
            const nextPos = { ...blockPosition, y: nextY };

            const isCollide = checkCollision(currentBlock.shape, nextPos, grid);

            if (isCollide) {
                // 로그
                // console.log('바닥에 닿음!!');

                // 블럭을 필드에 고정
                const newGrid = [...grid.map(row => row)];
                for (let y = 0; y < currentBlock.shape.length; y++) {
                    for (let x = 0; x < currentBlock.shape[y].length; x++) {
                        if (currentBlock.shape[y][x]) {
                            const gy = blockPosition.y + y;
                            const gx = blockPosition.x + x;
                            if (grid[gy]?.[gx] !== 0) {
                                GameOver();
                                return true;
                            }
                            if (gy >= 0 && gy < Field.ROWS && gx >= 0 && gx < Field.COLS) {
                                newGrid[gy][gx] = currentBlock.shape[y][x];
                            }
                        }
                    }
                }
                setGrid(clearFullLines(newGrid));
                // 다음 블럭으로 교체
                spawmBlock();
            } else {
                setBlockPosition(nextPos);
            }
        }, 500);  // 500ms 마다 떨어짐, (5초에 한칸씩)
        return () => clearInterval(interval);
    }, [blockPosition, currentBlock, grid]);

    // 바닥 미리 깔아둔것
    useEffect(() => {
        // 로그
        // console.log('🟢 useEffect 진입');
        const testGrid = createEmptyField();
        // 로그
        // console.log('📦 초기 필드 생성 완료');
        for (let x = 0; x < Field.COLS - 1; x++) {
            // 맘대로 재배치 하는법
            // [줄(세로)][칸(가로)] -> 0~19 0~9 사이면 됨
            // = 뒤에 'color' 넣을것
            testGrid[19][0] = 'blue';
            testGrid[19][1] = 'orange';
            testGrid[19][2] = 'greenyellow';
            testGrid[19][6] = 'red';
            testGrid[19][7] = 'violet';
            testGrid[19][8] = 'yellow';
            testGrid[19][9] = 'aqua';
            // 로그
            // console.log('바닥 작동함');
        }
        // 로그
        // console.log('✅ 바닥 셋업 완료:', testGrid[19][9]);

        setGrid(testGrid);
    }, []);

    return (
        <div className="tetra_field_test">
            <div className="tetra_grid"
                style={{
                    gridTemplateColumns: `repeat(${Field.COLS}, 1fr)`,
                    gridTemplateRows: `repeat(${Field.ROWS}, 1fr)` }}>
                {grid.map((row, rowIdx) => row.map((cell, colIdx) => {
                    let cellValue = cell;
                    // 블럭이 이 위치에 있는지 확인
                    if (currentBlock && currentBlock.shape) {
                        const { shape, color } = currentBlock;
                        const { x, y } = blockPosition;

                        for (let i = 0; i < shape.length; i++) {
                            for (let j = 0; j < shape[i].length; j++) {
                                if (shape[i][j] && rowIdx === y + i && colIdx === x + j) {
                                    cellValue = color ?? 'black';
                                }
                            }
                        }
                    }
                    return (
                        <div key={`${rowIdx}-${colIdx}`}
                        className='tetra_cell' style={{ backgroundColor: cellValue ? cellValue : 'transparent' }} />
                    )
                }))}
            </div>
        </div>
    );
}

export default TetraField;