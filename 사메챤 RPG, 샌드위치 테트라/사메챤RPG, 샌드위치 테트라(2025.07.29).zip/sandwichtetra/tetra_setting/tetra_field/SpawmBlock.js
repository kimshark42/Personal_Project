import GetRandomBlock from "./GetRandomBlock";

function SpawmBlock() {
    const block = GetRandomBlock();
}

export default SpawmBlock;