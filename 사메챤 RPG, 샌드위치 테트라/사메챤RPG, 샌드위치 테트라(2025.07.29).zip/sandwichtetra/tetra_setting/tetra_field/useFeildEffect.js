// import { useEffect } from "react"
// import Field from "./Field";

// const useFieldEffect = ({
//     blockPosition,
//     checkCollision,
//     currentBlock,
//     grid,
//     GameOver,
//     setGrid,
//     clearFullLines,
//     spawmBlock,
//     setBlockPosition
// }) => {

//     // 블럭 드롭
//     useEffect(() => {
//         const interval = setInterval(() => {
//             const nextY = blockPosition.y + 1;
//             const nextPos = { ...blockPosition, y: nextY };

//             const isCollide = checkCollision(currentBlock.shape, nextPos, grid);

//             if (isCollide) {
//                 const newGrid = [...grid.map(row => row)];
//                 for (let y = 0; y < currentBlock.shape.length; y++) {
//                     for (let x = 0; x < currentBlock.shape[y].length; x++) {
//                         if (currentBlock.shape[y][x]) {
//                             const gy = blockPosition.y + y;
//                             const gx = blockPosition.x + x;
//                             // 게임오버
//                             if (grid[gy]?.[gx] !== 0) {
//                                 GameOver();
//                                 return true;
//                             }
//                             if (gy >= 0 && gy < Field.ROWS && gx >= 0 && gx < Field.COLS) {
//                                 newGrid[gy][gx] = currentBlock.shape[y][x];
//                             }
//                         }
//                     }
//                 }
//                 setGrid(clearFullLines(newGrid));
//                 spawmBlock();
//             } else {
//                 setBlockPosition(nextPos);
//             }
//         },500);  // 500ms 마다 떨어짐, (5초에 한칸씩)
//         return () => clearInterval(interval);
//     }, [blockPosition, currentBlock, grid]);
// }

// export default useFieldEffect;