import Field from "./Field";

const createEmptyField = () => Array.from({ length: Field.ROWS }, () => Array(Field.COLS).fill(0));

export default createEmptyField;