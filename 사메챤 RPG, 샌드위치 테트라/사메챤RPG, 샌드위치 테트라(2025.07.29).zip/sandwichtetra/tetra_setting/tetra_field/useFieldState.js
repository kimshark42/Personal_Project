import { useState } from "react";

import Field from "./Field";
import createEmptyField from "./CreateEmptyField";

const useFieldState = () => {

    // 필드 격자 상태
    const [grid, setGrid] = useState(createEmptyField());

    // 블럭 상태
    const [currentBlock, setCurrentBlock] = useState({ shape: [], color: '' });  // 블럭 모양및 색깔
    const [blockPosition, setBlockPosition] = useState({ x: 0, y: 0 });  // 블럭 위치

    // 게임 오버
    const [isGameOver, setIsGameOver] = useState(false);

    return {
        grid, setGrid,
        currentBlock, setCurrentBlock,
        blockPosition, setBlockPosition,
        isGameOver, setIsGameOver
    };
};

export default useFieldState;