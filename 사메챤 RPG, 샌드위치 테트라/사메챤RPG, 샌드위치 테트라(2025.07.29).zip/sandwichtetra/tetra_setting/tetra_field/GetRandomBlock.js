import TETRAS from '../TETRAS.js';

// 블럭을 랜덤으로 가져옴
function GetRandomBlock() {
    const keys = Object.keys(TETRAS);
    const randKey = keys[Math.floor(Math.random()*keys.length)];
    return TETRAS[randKey];
}

export default GetRandomBlock;