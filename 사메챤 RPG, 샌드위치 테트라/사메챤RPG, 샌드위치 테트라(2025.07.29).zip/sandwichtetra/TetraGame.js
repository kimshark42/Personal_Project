import { useState } from "react";

import './TeterGame.css';

import PAGE from "../process/PAGE";
import TetraField from "./tetra_setting/tetra_field/TetraField";

// 카드 임시
function CardTest({sea}) {
    return (
        <div className={`card ${sea}`}>
            {sea}
        </div>
    )
}

function TetraGame({ changePageMode }) {

    // 임시 배열
    var[cardtest] = useState(['상어','고래상어','문어']);

    return (
        <div className="tetra_layout">
            <div className="tetra_body">
                <div className="tetra_fild_body">
                    <TetraField />
                </div>
                <div className="content_buttons">
                    <div className="tetra_gamelogo"></div>
                    <div className="tetra_test">
                        <div className="card_test">{cardtest.map((c)=>(<CardTest sea={c} />))}</div>
                        <button onClick={()=>changePageMode(PAGE.SANDWICH_TETRA)}>이전으로</button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default TetraGame;