import { useState } from "react";

import { PAGE } from "./PAGE";
import Main from "../main/Main";
import SandwichMain from "../sandwich_tetra/sandwich_main/SandwichMain";
import SandwichGame from "../sandwich_tetra/sandwich_game/SandwichGame";
import RpgMain from "../samechan_rpg/rpg_main/RpgMain";

function SharkController() {

    // 여러 페이지 상태를 배열로 분리
    var [currentPage, setCurrentPage] = useState(PAGE.MAIN);  // 기본 페이지 상태를 메인으로 설정

    // 페이지를 바꾸기 위한 도우미 함수
    function changePageMode(page){setCurrentPage(page);}

    return (
        <div>
            {/* 기본 페이지를 Main.js로 출력하게끔 세팅 */}
            {currentPage === PAGE.MAIN && <Main changePageMode={changePageMode} />}
            {currentPage === PAGE.SANDWICH_TETRA && <SandwichMain changePageMode={changePageMode} />}
            {currentPage === PAGE.SAMECHAN_RPG && <RpgMain changePageMode={changePageMode} />}

            {/* 샌드위치 테트라 관련 */}
            {currentPage === PAGE.SANDWICH_GAME && <SandwichGame changePageMode={changePageMode} />}

            {/* 사메챤 RPG 관련 */}
        </div>
    );
}

export default SharkController;