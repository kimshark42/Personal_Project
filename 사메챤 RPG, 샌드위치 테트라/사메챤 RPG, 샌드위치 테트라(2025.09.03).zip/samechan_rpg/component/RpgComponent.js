import './RpgComponent.css';

import { useState } from "react";

// Rpg레이아웃
function RpgComponent({ children }) {

    // children에 값이 없을때의 예외처리
    const sidebar = children?.sidebar;
    const main = children?.main;

    // 사이드바 펼치고 접기
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="rpg_layout">
            {/* 사이드바 버튼 */}
            <button className="toggle_button" onClick={() => setIsOpen(!isOpen)}>{isOpen ? '🦈' : '🐟' }</button>
            <aside className={`sidebar ${isOpen ? "closed" : ""}`}>
                {/* <div className="scroll_content"> */}
                    {/* 사이드바 내부 */}
                    {children.sidebar}
                {/* </div> */}
            </aside>

            {/* 메인 컨텐츠 영역 */}
            <main className="main_content">
                {/* 메인 컨텐츠 내부 */}
                {children.main}
            </main>
        </div>
    );
}

export default RpgComponent;