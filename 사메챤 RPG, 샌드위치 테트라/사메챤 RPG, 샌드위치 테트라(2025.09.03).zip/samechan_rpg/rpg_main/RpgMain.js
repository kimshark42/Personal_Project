import './RpgMain.css';

import RpgComponent from "../component/RpgComponent";
import { PAGE } from '../../process/PAGE';

// RPG 메인
function RpgMain({ changePageMode }) {

    // 버튼들을 배열로 정리
    const levels = [ "기본", "중급", "고급", "무작위" ];
    const actions = [ "캐릭터 생성", "도전 과제 부스트", "갤러리" ];

    return (
        <RpgComponent>
            {{
                sidebar: (
                    <aside>
                        {/* 사이드바 내부 */}
                        <div className='rpg_main_logo'></div>
                        <p>Version 0.0.0</p><br/>
                        <div className='rpg_main_clock'>00:00</div>
                        <div className='rpg_main_sidbar_button'>
                            <button>세이브</button>
                            <button>옵션</button>
                            <button>도전과제</button>
                            <button onClick={() => changePageMode(PAGE.MAIN)}>메인 페이지로 돌아가기</button>
                        </div>
                    </aside>
                ), main: (
                    <div>
                        {/* 메인 컨텐츠 영역 */}
                        <div className='rpg_main_big_logo'>로고</div>
                        <h1>사메챤 RPG</h1>
                        <div className='rpg_main_button_setting'>
                            <button>버튼1</button>
                            <button>버튼2</button>
                            <button>버튼3</button>
                            <button>버튼4</button>
                            <button>버튼5</button>
                            <button>버튼6</button>
                        </div>
                    </div>
                )
            }}
        </RpgComponent>
    );
}

export default RpgMain;