// !!!!!!!!!! [이 파일 안씀] !!!!!!!!!!
// styled 사용하는법
//npm install styled-components 를 설치한다 -> 사용한다
// 주의할점
// ㄴ> css 문법을 맞출것, ; 뒤에 이거 붙일것, 근데 주석은 // 이걸로 쳐도됨
import React from "react";
import styled from "styled-components";  // 이거 자동 임포트 안되니 수동으로 할것
import { TETRAS } from '../../TETRAS.js';

const StyledCell = styled.div`
    border: ${({ border }) => border || '1px solid black' };  /* props 로 border 수치 받아오기 + 받아온 값이 없을경우 기본값 출력 */
    box-sizing: border-box;
    background-color: ${({ color }) => color || 'white' };
    aspect-ratio: 1/1;
    width: 100%;
    height: 100%; `;

const Cell = ({ type }) => {
    const { color, border } = TETRAS[type] || TETRAS[0];  // 이거 읽히고 싶으면 한칸짜리 정의해둬야함

    return (
        <StyledCell type={type} color={color} border={border}><div></div></StyledCell>
    );
}

export default React.memo(Cell); // 최적화용 한번 렌더링 된 Cell을 재활용해서 씀