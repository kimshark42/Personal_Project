import './RpgMain.css';

import RpgComponent from "../rpg_component/RpgComponent";

function RpgMain({ changePageMode }) {

    // 버튼들 배열로 정리
    const levels = [ "기본", "중급", "고급", "무작위" ];
    const actions = [ "캐릭터 생성", "도전 과제 부스트", "갤러리" ];

    return (
        <RpgComponent
            sidebar={
                <aside>
                    {/* 사이드바 내부 */}
                    <h2>사메챤 RPG(로고 짤로 변경 바람)</h2><br/>
                    <div className="logo_rpg"></div>
                    <p>Version 0.0.0 </p><br/>
                    <div className="game_clock_main">00:00</div>

                    <div className="sidebar_button_main">
                        <button>세이브</button>
                        <button>옵션</button>
                        <button>도전과제</button>
                    </div>
                </aside>
            }
            main={
                <div>
                    <div className="big_logo">큰 로고</div>
                    <h1>사메챤 RPG</h1>
                    <section>
                        <p>세이브 데이터 관련 사항</p>
                        <p>설정 선택:</p>
                        <div className="rpg_button_setting-height">
                            {levels.map(level => (<button key={level}>{level}</button>))}
                        </div>
                    </section>

                        <hr/>

                    <section className="rpg_button_setting-row">
                        {actions.map(action => (<button key={action}>{action}</button>))}
                    </section>

                    <div className='setting_box'>기본시작: 난이도를 기본값으로 지정합니다 몬스터와 NPC들은 무작위로 생성됩니다 </div>

                    <section className="save_box">
                        <label>세이브 이름:</label>
                        <input type="text" placeholder="입력하세요" />
                    </section>

                    <div className="game_start">
                        <label>현재 설정:</label>
                        <button className="start_button">(1)게임을 시작하지</button>
                    </div>
                </div>
            }/>
    );
}

export default RpgMain;