import './RpgComponent.css';

import { useState } from "react";

function RpgComponent({ sidebar, main }) {

    // 사이드바 펼치고 접기
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="rpg_layout">
            {/* 사이드바 */}
            <button className="sidebar_button" onClick={() => setIsOpen(!isOpen)}>
                {isOpen ? '◀' : '▶'}
            </button>
            <div className={`sidebar ${isOpen ? "isOpen" : ""}`}>
                <div className="scroll_content">
                    {/* 사이드바 내부 */}
                    {sidebar}
                </div>
            </div>

            {/* 메인 컨텐츠 영역 */}
            <div className="main_content">
                {/* 메인 컨텐츠 내부 */}
                {main}
            </div>
        </div>
    );
}

export default RpgComponent;