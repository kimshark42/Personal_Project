import { useState } from "react";
import PAGE from "./PAGE";
import RpgMain from "../samechan_rpg/rpg_main/RpgMain";

// 페이지 넘기는 코드
function SharkController() {
    
    // 여러 페이지 변경 상태
    var [currentPage, setCurrentPage] = useState(PAGE.SAMECHAN_RPG);  // 첫 페이지를 사메챤 RPG로 설정

    // 페이지를 바꾸기 위한 도우미 함수
    function changePageMode(page){setCurrentPage(page);}

    return (
        <div>
            {/* 기본 페이지를 Samechan_rpg로 출력 */}
            {currentPage === PAGE.SAMECHAN_RPG && <RpgMain changePageMode={changePageMode} />}
        </div>
    );
}

export default SharkController;