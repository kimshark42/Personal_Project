// 페이지 넘기는 상수 모음

const PAGE = {

    // 메인 페이지
    SAMECHAN_RPG : 'samechan_rpg',  // 사메챤 RPG

}

export default PAGE;