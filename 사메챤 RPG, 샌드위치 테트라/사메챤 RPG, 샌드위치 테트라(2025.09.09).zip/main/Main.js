import './Main.css';

import { PAGE } from '../process/PAGE.js';

// 메인 화면
function Main({ changePageMode }) {
    return (
        <div className="main">
            <div className="main_button">
                <button onClick={() => changePageMode(PAGE.SANDWICH_TETRA)}>샌드위치 테트라</button>
                <button onClick={() => changePageMode(PAGE.SAMECHAN_RPG)}>사메챤RPG</button>
                <button onClick={() => changePageMode(PAGE.Daii)}>에러용 페이지</button>
            </div>
        </div>
    );
}

export default Main;