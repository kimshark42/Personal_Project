import './RpgMain.css';

import RpgComponent from "../component/RpgComponent";
import { PAGE } from '../../process/PAGE';

// RPG 메인
function RpgMain({ changePageMode }) {

    // 버튼들을 배열로 정리
    const levels = [ "기본", "중급", "고급", "무작위" ];
    const actions = [ "캐릭터 생성", "도전 과제 부스트", "갤러리" ];

    return (
        <RpgComponent
                sidebar={
                    <aside>
                        {/* 사이드바 내부 */}
                        <div className='rpg_main_logo'></div>
                        <p>Version 0.0.0</p><br/>
                        <div className='rpg_main_clock'>00:00</div>
                        <div className='rpg_main_sidbar_button'>
                            <button>세이브</button>
                            <button>옵션</button>
                            <button>도전과제</button>
                            <button onClick={() => changePageMode(PAGE.MAIN)}>메인 페이지로 돌아가기</button>
                        </div>
                    </aside>
                } main={
                    <div>
                        {/* 메인 컨텐츠 영역 */}
                        <div className='rpg_main_big_logo'>로고</div>
                        <h1>사메챤 RPG</h1>
                        <section>
                            <p>세이브 데이터 관련 사항</p>
                            <p>설정 선택:</p>
                            <div className='rpg_main_setting_button-height'>
                                {levels.map(level => (<button key={level}>{level}</button>))}
                            </div>
                        </section>
                        <hr/>
                        <section className='rpg_main_setting_button-row'>
                            {actions.map(action => (<button key={action}>{action}</button>))}
                        </section>
                        <div className='rpg_main_setting_box'>기본시작: 난이도를 기본 값으로 지정합니다</div>
                        <section className='rpg_main_save_box'>
                            <label>세이브 이름: <input type='text' placeholder='입력하세요'/></label>
                        </section>
                        <div className='rpg_main_game_start'>
                            <label>
                                현재 설정: 
                                <button onClick={() => changePageMode(PAGE.SAMECHAN_GAME)} className='rpg_main_game_start_button'>
                                    (1) 게임을 시작하지
                                </button>
                            </label>
                        </div>
                    </div>
                }/>
    );
}

export default RpgMain;