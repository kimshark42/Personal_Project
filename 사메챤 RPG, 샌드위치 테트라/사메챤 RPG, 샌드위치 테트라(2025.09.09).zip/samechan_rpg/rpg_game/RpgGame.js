import './RpgGame.css';

import { PAGE } from "../../process/PAGE";
import RpgComponent from "../component/RpgComponent";
import GameTimer from './game_timer/GameTimer';
import TurnButton from './game_timer/TurnButton';

function RpgGame({ changePageMode }) {

    // 시계
    const { display, advanceTurn } = GameTimer();

    return (
        <RpgComponent
            sidebar={
                <aside>
                    {/* 사이드바 내부 */}
                    <div className="rpg_game_character"></div>
                    <div className="rpg_game_character_status-top">
                        <span>돈 $ 10,346</span>
                        {/* <span>AM 10:27</span> */}
                        <TurnButton display={display}/>
                        <span>📆 Tus</span>
                    </div>
                    <div className="rpg_game_character_quest">
                        <p>현재 목표: 헤어쿠폰 도둑놈들을 쫒자</p>
                        <h1>상태: 조금 퍼석해진 머리</h1>
                        <p className='status_line hp'>HP: <strong>멀쩡하다!!</strong></p>
                        <p className='status_line mp'>MP: <strong>흘러넘치는 마력!!</strong></p>
                        <p className='status_line atc'>기타: <strong>어딘가엔 쓰겠지</strong></p>
                    </div>
                    <div className='rpg_game_tip'>
                        Tip: 이기려면 칼을 싸게싸게 뽑읍시다
                    </div>
                    <div className="rpg_game_side-button">
                        <button>장비창</button>
                        <button onClick={() => changePageMode(PAGE.SAMECHAN_RPG)}>타이틀</button>
                        <button>세이브</button>
                        <button>옵션</button>
                        <button>도전과제</button>
                        <button>치트</button>
                    </div>
                </aside>
            } main={
                <div className="rpg_game_main_content">
                    {/* 메인 컨텐츠 영역 */}
                    <div className="rpg_game_panel">
                        <textarea className="screen_game_object" readOnly>게임 오브젝트 패널</textarea>
                        <textarea className="screen_message_box" readOnly>게임 패널</textarea>
                        <textarea className="screen_player_info" readOnly>게임 캐릭터 패널</textarea>
                        <hr/>
                        <div className="rpg_game_bottom_button">
                            <input className="input_txt_turn" readOnly/>
                            <input className="turn_button" type='button' value="[턴 진행]"/>
                        </div>
                    </div>
                    <div className="rpg_game_map">게임 맵</div>
                </div>}/>
    );
}

export default RpgGame;