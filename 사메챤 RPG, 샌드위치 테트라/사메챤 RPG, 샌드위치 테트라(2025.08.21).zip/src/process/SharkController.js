import { useState } from "react";
import { PAGE } from "./PAGE.js";
import Main from "../main/Main";
import SandwichMain from "../sandwich_tetra/sandwich_main/SandwichMain";
import SandwichGame from "../sandwich_tetra/sandwich_game/SandwichGame.js";

// 페이지 전환 코드
function SharkController() {

    // 여러 페이지 상태를 배열로 분리
    var [currentPage, setCurrentPage] = useState(PAGE.MAIN);  // 기본 페이지를 Main으로 지정

    // 페이지 전환을 위한 도우미 함수
    function changePageMode(page){setCurrentPage(page);}

    return (
        <div>
            {/* 기본 페이지를 Main.js로 출력하게끔 세팅 */}
            {currentPage === PAGE.MAIN && <Main changePageMode={changePageMode} />}

            {/* 샌드위치 테트라 */}
            {currentPage === PAGE.SANDWICH_TETRA && <SandwichMain changePageMode={changePageMode} />}
            {currentPage === PAGE.SANDWICH_GAME && <SandwichGame changePageMode={changePageMode} />}
        </div>
    );
}

export default SharkController;