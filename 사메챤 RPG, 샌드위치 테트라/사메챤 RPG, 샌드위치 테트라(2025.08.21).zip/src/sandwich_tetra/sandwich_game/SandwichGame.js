import './SandwichGame.css';

import { PAGE } from '../../process/PAGE.js';

function SandwichGame({ changePageMode }) {

    return (
        <div className='sandwich_game'>
            <div className='sandwich_game_content'>
                <div className='sandwich_game_field'>
                    <h1>TetraField</h1>
                </div>
                <div className='sandwich_game_content_buttons'>
                    <div className='sandwich_game_logo'></div>
                    <button>시작</button>
                    <button>설정</button>
                    <button>도움말</button>
                    <button onClick={() => changePageMode(PAGE.SANDWICH_TETRA)}>이전으로</button>
                </div>
            </div>
        </div>
    );
}

export default SandwichGame;