import styled from 'styled-components';
import { LINE } from '../TETRA';

const StyledField = styled.div`
    display: grid;
    width: 100%;
    heigth: 100%;
    grid-template-colums: repeat(${props => props.cols}, 1fr);
    grid-template-rows: repeat(${props => props.rows}, 1fr);
    `

function Field() {

    // 임시
    return (
        <StyledField rows={LINE.ROWS} cols={LINE.COLS}>
            {}
        </StyledField>
    );
}