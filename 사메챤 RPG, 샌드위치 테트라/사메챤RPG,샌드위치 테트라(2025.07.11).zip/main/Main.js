// 메인화면
import './Main.css';

import PAGE from "../process/PAGE";

function Main({changePageMode}) {
    return (
        <div className="main">
            <div className="main_button">
                <button onClick={()=> changePageMode(PAGE.SAMECHAN_RPG)}>사메챤RPG</button>
                <button onClick={()=> changePageMode(PAGE.SANDWICH_TETRA)}>샌드위치 테트라</button>
            </div>
        </div>
    );
}

export default Main;