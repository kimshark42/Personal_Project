/*******************************************************************************************************************************/
// 테트리스 필드 부분
// 테트리스의 필드(격자무늬) 생성
const ROWS = 20;  // 세로줄 갯수
const COLS = 10;  // 가로칸 갯수

// 20x10 칸짜리 배열을 만드는 함수, 0은 빈칸으로 취급
const createEmptyField = () => Array.from({ length: ROWS }, () => Array(COLS).fill(0));
// 위에서 만든 빈 필드를 useState로 저장
const [field, setField] = useState(createEmptyField());
/*******************************************************************************************************************************/

function TetraGame() {
    return (
        <div>
            테스트용 div
        </div>
    );
}

export default TetraGame;