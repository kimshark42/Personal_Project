import './SandwichMain.css';

import PAGE from "../process/PAGE";

function SandwichMain({changePageMode}) {
    return (
        <div className="sandwich_main">
            <div className="sandwich_content">
                <div className="sandwich_big_logo"></div>
                <div className="sandwich_main_buttons">
                    <button onClick={()=>changePageMode(PAGE.TEST_TETERES)}>테스팅용 테트리스</button>
                    <button>버튼 2</button>
                    <button>버튼 3</button>
                    <button>버튼 4</button>
                    <button>버튼 5</button>
                    <button onClick={()=>changePageMode(PAGE.MAIN_PAGE)}>메인페이지로 돌아가기</button>
                </div>
            </div>
        </div>
    );
}

export default SandwichMain;