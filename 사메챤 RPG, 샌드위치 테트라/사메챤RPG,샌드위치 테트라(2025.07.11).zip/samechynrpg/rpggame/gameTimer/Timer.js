function Timer({ hours, minuites }){

    let displayHoures = hours % 12;
    if (displayHoures === 0)displayHoures = 12;  // 12시가 넘으면 0시로 리셋되게끔 설정

    // 오전/오후, 시, 분 정의
    const period = hours < 12 ? 'AM' : 'PM';
    const h = hours.toString().padStart(2,'0');
    const m = minuites.toString().padStart(2,'0');

    // 시계 출력
    const display = `${h}:${m} ${period}`;

    return (
        <div className="game_clock">{display}</div>
    );
}

export default Timer;