// 인게임 타이머 구성
import { useState } from "react";

import './GameTimer.css';

function GameTimer() {

    // 초기 시/분 설정
    // js 에서는 let을 썼지만 react에서는 굳이 그럴 필요가 없으므로 useState를 활용 시게 UI와 직접적으로 연동
    const [minuites, setMinuites] = useState(0);
    const [hours, setHours] = useState(0);

    // 턴 진행 함수
    function advanceTurn() {
        let newMinuites = minuites + 15;  // 턴 진행 할 때마다 15분씩 지나게끔 설정
        let newHours = hours;

        // 만약 60분을 넘겼다면 0으로 초기화 후 1시간 증가하게끔 설정
        if(newMinuites >= 60 ) {
            newHours += 1;
            newMinuites -= 60;
        }
        setHours(newHours);
        setMinuites(newMinuites);
    }

    const display = (() => {
        const h12 = hours % 12 || 12;
        const period = hours < 12 ? "AM" : "PM";
        const h = hours.toString().padStart(2,'0');
        const m = minuites.toString().padStart(2,'0');
        return `${h}:${m} ${period}`;
        })();

        return { display, advanceTurn, hours, minuites };
}

export default GameTimer;