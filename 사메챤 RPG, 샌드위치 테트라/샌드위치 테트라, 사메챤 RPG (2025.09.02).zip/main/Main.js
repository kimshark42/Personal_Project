import './Main.css';

import { PAGE } from '../process/PAGE.js';

// 메인 화면
function Main({ changePageMode }) {
    return (
        <div className="main">
            <div className="main_button">
                <button onClick={() => changePageMode(PAGE.SANDWICH_TETRA)}>샌드위치 테트라</button>
            </div>
        </div>
    );
}

export default Main;