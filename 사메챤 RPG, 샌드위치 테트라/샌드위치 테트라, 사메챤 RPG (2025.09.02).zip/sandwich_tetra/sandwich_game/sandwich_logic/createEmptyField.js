import { LINE } from "../TETRAS.js";

// 빈 필드 생성 개선판
// const createEmptyField = () => {
//     return Array.from({ length: LINE.ROWS }, () => Array.from({ length: LINE.COLS }, () => [0, 'clear']));
// };

// 빈 필드 생성
const createEmptyField = () => Array.from({ length: LINE.ROWS }, () => Array(LINE.COLS).fill(0));

export default createEmptyField;