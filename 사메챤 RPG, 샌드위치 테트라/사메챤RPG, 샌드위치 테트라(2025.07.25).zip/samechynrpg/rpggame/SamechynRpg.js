import './SamechynRpg.css';

import PAGE from "../../process/PAGE";
import RpgComponent from "../rpgcomponent/RpgComponent";
import GameTimer from './gameTimer/GameTimer';
import TurnButton from './gameTimer/TurnButton';
import { useState } from 'react';
import useTextareaOut from './util/useTextareaOut';

function Samechan_rpg_game({ changePageMode }) {

    const {display, advanceTurn} = GameTimer();

    // 커스텀 훅 형태로 게임 상태 관리
    const {
        messageLog,
        gameObjectLog,
        playerInfo,
        turnCount,
        handleTurn,
    } = useTextareaOut(advanceTurn);

    return (
        <RpgComponent>
            {{
                sidebar: (
                    <div>
                        {/* 사이드바 내부 */}
                        <div className="character"></div>
                        <TurnButton display={display} />
                        <button onClick={()=>changePageMode(PAGE.SAMECHAN_RPG)}>이전으로</button>
                    </div>
                ), main: (
                    <div className="game_main_content">
                        {/* 메인 컨텐츠 영역 */}
                        <div className="game_panel">
                            <textarea className="screen_game_object" readOnly value={gameObjectLog}></textarea>
                            <textarea className="screen_message_box" readOnly value={messageLog}></textarea>
                            <textarea className="screen_player_info" readOnly value={playerInfo}></textarea>
                            <hr />
                            <div className="bottom_button">
                                <input className="input_txt_turn" value={turnCount} readOnly />
                                <input className="turn_button" type="button" value="[턴 진행]" onClick={handleTurn} />
                            </div>
                        </div>
                        <div className="game_map"></div>
                    </div>
                )
            }}
        </RpgComponent>
    );
}

export default Samechan_rpg_game;