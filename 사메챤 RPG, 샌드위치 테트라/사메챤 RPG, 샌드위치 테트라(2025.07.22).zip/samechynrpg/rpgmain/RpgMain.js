import './RpgMain.css';

import PAGE from "../../process/PAGE";
import RpgComponent from '../rpgcomponent/RpgComponent';

function RpgMain({changePageMode}) {

    return (
        <RpgComponent>
            {{
                sidebar: (
                    <div>
                        {/* 사이드바 내부 */}
                        <div className="logo_rpg"></div>
                        <div className="game_clock_main">00:00</div>
                        <p>사이드바 내용</p>
                        <button onClick={()=>changePageMode(PAGE.MAIN_PAGE)}>메인페이지로 돌아가기</button>
                    </div>
                ), main: (
                    <div>
                        {/* 메인 컨텐츠 영역 */}
                        <div className="big_logo_rpg"></div>
                        <h1>사메챤 RPG</h1>

                        {/* jsx 방식 */}
                        <div className="button_setting_rpg">
                            <button onClick={()=>changePageMode(PAGE.SAMECHAN_RPG_GAME)}>게임 시작</button>
                            <button>따이 2</button>
                            <button>따이 3</button>
                            <button>따이 4</button>
                            <button>따이 5</button>
                            <button>따이 6</button>
                        </div>
                    </div>
                )
            }}
        </RpgComponent>
    );
}

export default RpgMain;