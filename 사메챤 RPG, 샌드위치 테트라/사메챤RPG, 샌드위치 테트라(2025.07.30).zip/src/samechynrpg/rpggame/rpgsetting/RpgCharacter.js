import RpgComponent from "../../rpgcomponent/RpgComponent";

function RpgCharacter({ changePageMode }) {
    return (
        <RpgComponent>
            <div>
                따이
            </div>
        </RpgComponent>
    );
}

export default RpgCharacter;