// 테트리스 모양 모음

// 테트리스 블록 형태 정의 (함수 바깥에 위치해야 매 렌더마다 다시 정의되지 않음)
// 0은 빈칸 1은 채워져 있는 칸

const TETRA = {
  I: {
    shape: [[ 1, 1, 1, 1 ]],
    color: 'aqua' },  // ㅡ

  O: {
    shape: [[ 1, 1 ],
            [ 1, 1 ]],
    color: 'yellow' },  // ㅁ

  T: {
    shape: [[ 0, 1, 0 ],
            [ 1, 1, 1 ]],
    color: 'violet' },  // ㅗ

  Z: {
    shape: [[ 1, 1, 0],
            [ 0, 1, 1]],
    color: 'red' },  // Z

  S: {
    shape: [[ 0, 1, 1],
            [ 1, 1, 0]],
    color: 'greenyellow' },  // S

  L: {
    shape: [[ 1, 0 ],
            [ 1, 0 ],
            [ 1, 1 ]],
    color: 'orange'},  // L
  
  J: {
    shape: [[ 0, 1 ],
            [ 0, 1 ],
            [ 1, 1 ]],
    color: 'blue' }  // J
}

// 가로 세로줄
const LINE = {

  // 가로
  ROWS: 20,

  // 세로
  COLS: 10

}

export {TETRA, LINE};