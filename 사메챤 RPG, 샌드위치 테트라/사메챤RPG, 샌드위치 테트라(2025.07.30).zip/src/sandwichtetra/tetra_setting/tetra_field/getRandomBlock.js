import { TETRA } from "../TETRAS";

// 블럭 무작위 선별
function getRandomBlock() {
    console.log('GetRandomBlock 작동함!!');  // 로그
    const keys = Object.keys(TETRA);
    const randomKey = keys[Math.floor(Math.random()*keys.length)];
    return TETRA[randomKey];
};

export default getRandomBlock;