import { useEffect, useState } from 'react';

import './TetraField.css';


import {TETRA, LINE} from '../TETRAS.js';  // 테트리스 블럭, 가로세로 격자
import createEmptyField from './createEmptyField.js';  // 빈 필드 생성
import getRandomBlock from './getRandomBlock.js';  // 블럭을 무작위로 가져옴
import checkCollision from './checkCollision.js';  // 블럭 충돌 감지
import clearFullLines from './clearFullLines.js';  // 줄 삭제 로직

function TetraField() {

    
    const [grid ,setGrid] = useState(createEmptyField());  // 필드 격자 상태
    // 블럭 상태
    const [currentBlock, setCurrentBlock] = useState ({ shape: [], color: ''});  // 블럭 모양
    const [blockPosition, setBlockPosition] = useState({ x: 0, y: 0 });  // 블럭 위치

    // 게임 오버상태
    const [isGameOver, setIsGameOver] = useState(false);
    
    // 새로운 블럭 스폰
    const spawnBlock = () => {
        const block = getRandomBlock();
        // const block = TETRA['O'];
        const { shape, color } = block;

        // 중앙 정렬
        const x = Math.floor((LINE.COLS - shape[0].length) / 2);
        const y = 0;

        const isBlocked = checkCollision({ tetromino: shape, position: { x, y }, grid});
        if (isBlocked) {
            gameOver();
        } else {
            setCurrentBlock({ shape, color });
            setBlockPosition({ x, y });
        }
    };

    // 게임오버 로직
    const gameOver = (() => {
        setIsGameOver(true);
        alert('꽈당큐...');
    });

    // 줄 삭제 로직
    // const clearFullLines = (grid) => {
    //     const newGrid = grid.filter(row => row.some(cell => cell === 0));  // 꽉찬 줄 제외
    //     const linesCleared = LINE.ROWS - newGrid.length;  // 줄 몇개 제거 되었는지

    //     // 위에서 줄 추가
    //     const emptyRows = Array.from({ length: linesCleared }, () => Array(LINE.COLS).fill(0));
    //     return [...emptyRows,...newGrid];
    // };

    // 랜덤으로 블럭 랜더링
    useEffect(() => {spawnBlock();},[]);
    
    // 블럭 드롭
    useEffect(() => {
        if (isGameOver) return;

        const interval = setInterval(() => {
            const nextY = blockPosition.y + 1;
            const nextPos = { ...blockPosition, y: nextY };

            const isCollide = checkCollision({
                tetromino: currentBlock.shape,
                position: nextPos,
                grid });

            if (isCollide) {
                // 로그
                // console.log('바닥에 닿음!!');

                // 블럭을 필드에 고정
                const newGrid = [...grid.map(row => row)];
                for (let y = 0; y < currentBlock.shape.length; y++) {
                    for (let x = 0; x < currentBlock.shape[y].length; x++) {
                        if (currentBlock.shape[y][x]) {
                            const gy = blockPosition.y + y;
                            const gx = blockPosition.x + x;
                            if (grid[gy]?.[gx] !== 0) {
                                gameOver();
                                return;
                            }
                            if (gy >= 0 && gy < LINE.ROWS && gx >= 0 && gx < LINE.COLS) {
                                newGrid[gy][gx] = currentBlock.shape[y][x];
                            }
                        }
                    }
                }
                setGrid(clearFullLines(newGrid));
                // 다음 블럭으로 교체
                spawnBlock();
            } else {
                setBlockPosition(nextPos);
            }
        }, 500);  // 500ms 마다 떨어짐, (5초에 한칸씩)
        return () => clearInterval(interval);
    }, [blockPosition, currentBlock, grid, isGameOver]);
    
    // 게임 오버 로직
    // useEffect(() => {
    //     if(!isGameOver) {
    //         spawnNextBlock();
    //     }
    // }, [isGameOver]);

    // 바닥 미리 깔아둔것
    useEffect(() => {
        // 로그
        // console.log('🟢 useEffect 진입');
        const testGrid = createEmptyField();
        // 로그
        // console.log('📦 초기 필드 생성 완료');
        for (let x = 0; x < LINE.COLS - 1; x++) {
            // 맘대로 재배치 하는법
            // [줄(세로)][칸(가로)] -> 0~19 0~9 사이면 됨
            // = 뒤에 'color' 넣을것
            testGrid[19][0] = 'blue';
            testGrid[19][1] = 'orange';
            testGrid[19][2] = 'greenyellow';
            testGrid[19][3] = 'black';
            testGrid[19][6] = 'red';
            testGrid[19][7] = 'violet';
            testGrid[19][8] = 'yellow';
            testGrid[19][9] = 'aqua';

            testGrid[18][9] = 'aqua';
            testGrid[18][8] = 'yellow';
            testGrid[18][7] = 'violet';
            testGrid[18][6] = 'red';
            testGrid[18][3] = 'black';
            testGrid[18][2] = 'greenyellow';
            testGrid[18][1] = 'orange';
            testGrid[18][0] = 'blue';
            // 로그
            // console.log('바닥 작동함');
        }
        // 로그
        // console.log('✅ 바닥 셋업 완료:', testGrid[19][9]);

        setGrid(testGrid);
    }, []);

    return (
        <div className="tetra_field_test">
            <div className="tetra_grid"
                style={{
                    gridTemplateColumns: `repeat(${LINE.COLS}, 1fr)`,
                    gridTemplateRows: `repeat(${LINE.ROWS}, 1fr)` }}>
                {grid.map((row, rowIdx) => row.map((cell, colIdx) => {
                    let cellValue = cell;
                    // 블럭이 이 위치에 있는지 확인
                    if (currentBlock && currentBlock.shape) {
                        const { shape, color } = currentBlock;
                        const { x, y } = blockPosition;

                        for (let i = 0; i < shape.length; i++) {
                            for (let j = 0; j < shape[i].length; j++) {
                                if (shape[i][j] && rowIdx === y + i && colIdx === x + j) {
                                    cellValue = color ?? 'black';
                                }
                            }
                        }
                    }
                    return (
                        <div key={`${rowIdx}-${colIdx}`}
                        className='tetra_cell' style={{ backgroundColor: cellValue ? cellValue : 'transparent' }} />
                    )
                }))}
            </div>
        </div>
    );
}

export default TetraField;